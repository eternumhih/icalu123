<?php

session_destroy();
unset($_SESSION['usuario']);
unset($_SESSION['senha']);
unset($_SESSION['logado']);
header("Location: ../");