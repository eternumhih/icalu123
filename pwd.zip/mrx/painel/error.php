<!DOCTYPE html>
<html>
<head>
	<title>?? ERROR ??</title>
	<style type="text/css">
		*{
			margin: 0px;
			padding: 0px;
		}

		body{
			margin: 40px;
			padding: 30px;
			font-family: Arial, Times New Roman;
			background-color: black;
			color: white;
		}
		#voltar{
			color: red;
			font-size: 30px;
		}
	</style>
</head>
<body>
	<center>
		<h1>Bro tu não tá logado ;-;</h1>
		<h3>contate whatssap: 62 9 9660-8845</h3>
		<br><br>
		<a href="../../" id="voltar">>Back</a>
	</center>

</body>
</html>