<?php
if ($_SERVER['REMOTE_ADDR'] != '187.44.151.17'){
  exit('Acesso não autorizado para o IP '. $_SERVER['REMOTE_ADDR']);
}