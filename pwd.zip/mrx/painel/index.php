﻿
<?php
error_reporting(0);
set_time_limit(0);
session_start();


if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../usuarios.txt");
$creditos = file("../usuarios/".$_SESSION['usuario'].".txt");
$total_usuarios_registrados = count($array_usuarios);

$continuar = false;
for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){


    $_SESSION['senha'] = $explode[1];
    $_SESSION['rank'] = $explode[2];
    $_SESSION['foto'] = $explode[3];
    $continuar = true; 
  }
}

if(!$continuar){
echo '<script language= "JavaScript">location.href="/"</script><br>';
die();
}


?>

<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">

  <title>Central | Painel</title>

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- para ios 7 style, 152x152 -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-barstyle" content="black-translucent">
  <link rel="apple-touch-icon" href="../assets/images/logo.png">
  <meta name="apple-mobile-web-app-title" content="FireChecker">
  <!-- for Chrome on Android, multi-resolution icon of 196x196 -->
  <meta name="mobile-web-app-capable" content="yes">
  <link rel="shortcut icon" sizes="196x196" href="../assets/images/logo.png">

  <!-- style -->
  <link rel="stylesheet" href="../assets/animate.css/animate.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/glyphicons/glyphicons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/material-design-icons/material-design-icons.css" type="text/css" />

  <link rel="stylesheet" href="../assets/bootstrap/dist/css/bootstrap.min.css" type="text/css" />
  <!-- build:css ../assets/styles/app.min.css -->
  <link rel="stylesheet" href="../assets/styles/app.css" type="text/css" />
  <!-- endbuild -->
  <link rel="stylesheet" href="../assets/styles/font.css" type="text/css" />
    <script src="scripts/sweetalert2.js"></script>
  <link rel="stylesheet" href="scripts/sweetalert3.css">
</head>
<body onload="refresh('dashboard.php')" class="pace-done dark" ui-class="dark">
  <div class="app" id="app">

<!-- ############ INICIO DA pace-done darkPAGINA -->

  <!-- aside -->
  <div id="aside" class="app-aside box-shadow-z3 modal fade lg nav-expand">
    <div class="left navside white dk" layout="column">
       <div class=" navbar-md" style="background-color:   #202023;">
        <!-- brand -->
        <a class="navbar-brand">


        	<img src="../assets/images/logo.png" alt="." class="hide">
        	<span class="hidden-folded inline"> <div class="brand-text brand-big visible text-uppercase"><strong class="text-primary"> CENTRAL</strong></div>


        </a>
        <!-- / brand -->
		</div>
      <div flex class="hide-scroll">
        <nav class="scroll">
          <div ui-include="'views/aside-top.php'"></div>


            <ul class="nav" ui-nav>
              <li class="nav-header hidden-folded">
                <small class="text-muted">Home</small>
              </li>

              <li>
                <a href="javascript:refresh('dashboard.php')" >
                  <span class="nav-icon">
                    <i class="fa fa-fire"></i>
                  </span>
                  <span  class="nav-text">Dashboard</span>
                </a>
              </li>

              <li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label">
                    <b class="label label-sm primary">5</b>
                  </span>
                  <span class="nav-icon">
                    <i class="fa fa-cogs"></i>
                  </span>
                  <span class="nav-text">Ferramentas</span>
                </a>

				<ul class="nav-sub">
           <li>

                    <a href="javascript:refresh('separador.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success ">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Separador de Email</span>
                    </a>
                  </li>
                   <li>

                    <a href="javascript:refresh('binchk.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success ">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Bin Checker</span>
                    </a>
                  </li>

				  <li>

                    <a href="javascript:refresh('cpfs.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success ">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Gerar Pessoas</span>
                    </a>
                  </li>

                  <li>

                    <a href="javascript:refresh('link.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success ">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Gerar CC's</span>
                    </a>
                  </li>
                     <li>

                    <a href="javascript:refresh('proxy.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success ">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> capturador de proxy</span>
                    </a>
                  </li>
                </ul>
              </li>


          <li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label">
                    <b class="label label-sm primary">2</b>
                  </span>
                  <span class="nav-icon">
                    <i class="fa fa-search"></i>
                  </span>
                  <span class="nav-text">Consultas</span>
                </a>
                <ul class="nav-sub">
                   <li>
                    <a href="javascript:refresh('cpf.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success ">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> CPF</span>
                    </a>
                  </li>

				  <li>
                    <a href="javascript:refresh('nome.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success ">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Nome</span>
                    </a>
                  </li>

                </ul>
              </li>

			  <li>
                <a href="javascript:refresh('chattt/chat.html')" >
                  <span class="nav-icon">
                    <i class="fa fa-user"></i>
                  </span>
                  <span class="nav-text">Chat</span>
                </a>
              </li>
			   <li>
                <a href="javascript:refresh('price.php')" >
                  <span class="nav-icon">
                    <i class="fa fa-cc"></i>
                  </span>
                  <span class="nav-text">Comprar</span>
                </a>
              </li>
			  <li class="nav-header hidden-folded">
                <small class="text-muted">Capturador CPF/Email Checker</small>
              </li>

			            <li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label">
                    <b class="label label-sm primary">5</b>
                  </span>
                  <span class="nav-icon">
                    <i class="fa fa-list"></i>
                  </span>
                  <span class="nav-text">Email/CPF</span>
                </a>
                <ul class="nav-sub">
                   <li>
                    <a href="javascript:refresh('existeml.php')" >
                    <span class="nav-label">
                    <b class="label label-sm danger">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> MercadoPago</span>
                    </a>
                  </li>

                   <li>
                    <a href="javascript:refresh('detectuber.php')" >
                    <span class="nav-label">
                    <b class="label label-sm danger">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Uber</span>
                    </a>
                  </li>

                   <li>
                    <a href="javascript:refresh('detectdotz.php')" >
                    <span class="nav-label">
                    <b class="label label-sm danger">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Dotz</span>
                    </a>
                  </li>

				 <li>
                    <a href="javascript:refresh('paypal.php')" >
                    <span class="nav-label">
                    <b class="label label-sm danger">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> PayPal</span>
                    </a>
                  </li>
                </ul>
              </li>

			  <li class="nav-header hidden-folded">
                <small class="text-muted">Logins Checkers</small>
              </li>

              <li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label">
                    <b class="label label-sm primary">4</b>
                  </span>
                  <span class="nav-icon">
                    <i class="fa fa-shopping-cart"></i>
                  </span>
                  <span class="nav-text">Lojas</span>
                </a>

              <ul class="nav-sub nav-mega nav-mega-3">


				<li>

                    <a href="javascript:refresh('americanas.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Americanas</span>
                    </a>
                  </li>



          <li>

                    <a href="javascript:refresh('magazine.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Magazine</span>
                    </a>
                  </li>






              <li>

                    <a href="javascript:refresh('digital.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> SuperDigital</span>
                    </a>
                  </li>


                  <li>


              

                    <a href="javascript:refresh('sumup.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Sumup</span>
                    </a>
                  </li>



                    <li>
 
                              <a href="javascript:refresh('wish.php')" >
                              <span class="nav-label">
                              <b class="label label-sm warning">OFF</b>
                            </span>
                                <span class="nav-text"><i class="fa fa-hand-o-right"></i> Wish</span>
                              </a>
                            </li>


 <li>
 
                              <a href="javascript:refresh('centauro.php')" >
                              <span class="nav-label">
                              <b class="label label-sm warning">OFF</b>
                            </span>
                                <span class="nav-text"><i class="fa fa-hand-o-right"></i> Centauro</span>
                              </a>
                            </li>

 <li>
 
                              <a href="javascript:refresh('disney.php')" >
                              <span class="nav-label">
                              <b class="label label-sm success">ON</b>
                            </span>
                                <span class="nav-text"><i class="fa fa-hand-o-right"></i> disney plus</span>
                              </a>
                            </li>

 <li>
 
                              <a href="javascript:refresh('bahia.php')" >
                              <span class="nav-label">
                              <b class="label label-sm success">ON</b>
                            </span>
                                <span class="nav-text"><i class="fa fa-hand-o-right"></i> Casas Bahia</span>
                              </a>
                            </li>






<li>
 
                              <a href="javascript:refresh('vivo.php')" >
                              <span class="nav-label">
                              <b class="label label-sm success">ON</b>
                            </span>
                                <span class="nav-text"><i class="fa fa-hand-o-right"></i> Meu Vivo</span>
                              </a>
                            </li>



				<li>

                    <a href="javascript:refresh('peixe.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Peixe</span>
                    </a>
                  </li>

				  <li>

                    <a href="javascript:refresh('pagseguro.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Pagseguro</span>
                    </a>
                  </li>

                  				<li>

                    <a href="javascript:refresh('netshoes.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Netshoes</span>
                    </a>
                  </li>

				                  				<li>

                    <a href="javascript:refresh('ingresso.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Ingresso</span>
                    </a>
                  </li>

                </ul>
              </li>




			  <li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label">
                    <b class="label label-sm primary">5</b>
                  </span>
                  <span class="nav-icon">
                    <i class="fa fa-car"></i>
                  </span>
                  <span class="nav-text">Corridas</span>
                </a>
                <ul class="nav-sub nav-mega nav-mega-3">
				  <li>

                    <a href="javascript:refresh('99pop.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> 99Pop</span>
                    </a>
                  </li>
                </ul>
              </li>


<li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label">
                    <b class="label label-sm primary">1</b>
                  </span>
                  <span class="nav-icon">
                    <i class="fa fa-money"></i>
                  </span>
                  <span class="nav-text">Logins</span>
                </a>
                <ul class="nav-sub nav-mega nav-mega-3">
                  <li>

                    <a href="javascript:refresh('ifood.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warnint">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> IFOOD  </span>
                    </a>
                  </li>

				  <li>

                    <a href="javascript:refresh('pp.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Paypal  </span>
                    </a>
                  </li>




                </ul>
              </li>



			  <li class="nav-header hidden-folded">
                <small class="text-muted">CC Checkers</small>
              </li>

              <li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label">
                    <b class="label label-sm primary">5</b>
                  </span>
                  <span class="nav-icon">
                    <i class="fa fa-credit-card"></i>
                  </span>
                  <span class="nav-text">Credit Card</span>
                </a>
                <ul class="nav-sub nav-mega nav-mega-3">
                  <li>

                    <a href="javascript:refresh('5067.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> Elo 5067 </span>
                    </a>
                  </li>
				   <li>

                    <a href="javascript:refresh('ggbb.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> GG BB  </span>
                    </a>
                  </li>

                                    <li>

                    <a href="javascript:refresh('hiper.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> GG HIPER </span>
                    </a>
                  </li>


      <li>

           <a href="javascript:refresh('allbins4.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> ELO/50/65 </span>
                    </a>
                  </li>
 <li>

           <a href="javascript:refresh('allbins2.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> ELO </span>
                    </a>
                  </li>

<li>

           <a href="javascript:refresh('allbins3.php')" >
                    <span class="nav-label">
                    <b class="label label-sm  warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> ALLBINS V3 </span>
                    </a>
                  </li>


<li>

           <a href="javascript:refresh('itau.php')" >
                    <span class="nav-label">
                    <b class="label label-sm warning">OFF</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> GG ITAU </span>
                    </a>
                  </li>







<li>

                    <a href="javascript:refresh('Allbins.php')" >
                    <span class="nav-label">
                    <b class="label label-sm success">ON</b>
                  </span>
                      <span class="nav-text"><i class="fa fa-hand-o-right"></i> GATE E-REDE </span>
                    </a>
                  </li>


                </ul>
              </li>




            </ul>
        </nav>
      </div>
      <div flex-no-shrink>
    <nav ui-nav>
  <ul class="nav">
    <li class="no-bg">
      <a href="../logout.php" >
        <span class="nav-icon">
         <i class="material-icons">&#xe8ac;</i>
        </span>
        <span class="nav-text">Sair</span>
      </a>
    </li>
  </ul>
</nav>

      </div>
    </div>
  </div>
  <!-- / aside -->

  <!-- content -->

  <div id="content" class="app-content box-shadow-z3" role="main">
    <div class="app-header info box-shadow-z4 navbar-md" style="background-color:   #202020;">
      <div class="navbar">
          <!-- Open side - Naviation on mobile -->
          <a data-toggle="modal" data-target="#aside" class="navbar-item pull-left hidden-lg-up">
            <i class="material-icons">&#xe5d2;</i>
          </a>
          <!-- / -->

          <!-- titulo da pagina -->
          <div class="navbar-item pull-left h5" ng-bind="$state.current.data.title" id="pageTitle"></div>

        <!-- navbar right -->

          <ul class="nav navbar-nav pull-right">

            <li class="nav-item dropdown pos-stc-xs">

              <a class="nav-link" href data-toggle="dropdown">

                 <i class="fa fa-bell text-lg m-4"></i><b class="label rounded danger up">1+</b>


              </a>
              <div ui-include="'views/notification.php'"></div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link clear" href data-toggle="dropdown">
                <span class="avatar w-3">
                  <img src="<?php echo $_SESSION['foto']?> " alt="<?php echo $_SESSION['usuario'];?>">
                  <i class="on b-white bottom"></i>
                </span>
              </a>
              <div ui-include="'views/user.php'"></div>
            </li>
            <li class="nav-item hidden-md-up">
              <a class="nav-link" data-toggle="collapse" data-target="#collapse">
                <i class="material-icons">&#xe5d4;</i>
              </a>
            </li>
          </ul>
          <!-- / navbar right -->


          <!-- navbar collapse -->
          <div class="collapse navbar-toggleable-sm" id="collapse">
            <!-- link and dropdown -->
            <ul class="nav navbar-nav">


            </ul>
            <!-- / -->
          </div>
          <!-- / navbar collapse -->
      </div>
    </div>

    <div class="app-body" id="view2">




<div class="padding" id="pagina">


</div>




    </div>
  </div>
  <!-- / -->

  <!-- TEMA E CORES -->
  <div id="switcher">
    <div class="switcher box-color dark-white text-color" id="sw-theme">
      <a href ui-toggle-class="active" target="#sw-theme" class="box-color dark-white text-color sw-btn">
        <i class="fa fa-gear"></i>
      </a>
      <div class="box-header">
        <h2>Temas</h2>
      </div>
      <div class="box-divider"></div>
      <div class="box-body">
        <p class="hidden-md-down">
          <label class="md-check m-y-xs"  data-target="folded">
            <input type="checkbox">
            <i class="green"></i>
            <span class="hidden-folded">Esconder Menu</span>
          </label>
          <label class="md-check m-y-xs" data-target="boxed">
            <input type="checkbox">
            <i class="green"></i>
            <span class="hidden-folded">Estilo Encaixotado</span>
          </label>
          <label class="m-y-xs pointer" ui-fullscreen>
            <span class="fa fa-expand fa-fw m-r-xs"></span>
            <span>Tela Cheia</span>
          </label>
        </p>

        <p data-target="themeID">

        <p>Temas:</p>
        <div data-target="bg" class="text-u-c text-center _600 clearfix">
          <label class="p-a col-xs-6 light pointer m-a-0">
            <input type="radio" name="theme" value="" hidden>
            Claro
          </label>
          <label class="p-a col-xs-6 grey pointer m-a-0">
            <input type="radio" name="theme" value="grey" hidden>
            Cinza
          </label>
          <label class="p-a col-xs-6 dark pointer m-a-0">
            <input type="radio" name="theme" value="dark" hidden>
            Escuro
          </label>
          <label class="p-a col-xs-6 black pointer m-a-0">
            <input type="radio" name="theme" value="black" hidden>
            Preto
          </label>
        </div>
      </div>
    </div>

    <div class="switcher box-color black lt" id="sw-demo">
      <a href ui-toggle-class="active" target="#sw-demo" class="box-color black lt text-color sw-btn">
        <i class="fa fa-list text-white"></i>
      </a>
      <div class="box-header">
        <h2>Em Breve</h2>
      </div>
      <div class="box-divider"></div>
      <div class="box-body">
        <div class="text-u-c text-center _600 clearfix">

          </a>
          <div
            class="p-a col-xs-6 lter">
            <span class="text">Em breve Um chat :)</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- / -->

<!-- ############ LAYOUT END-->

<!-- footer -->

    <div class="app-footer">
      <div class="p-a text-xs">

        <div class="pull-right text-muted">

          &copy; Copyright <strong>Central</strong> <span class="hidden-xs-down">- <font color=red><i class="fa fa-heart"></i></font> VersÃ£o Beta  <font color=Red> <i class="fa fa-heart"></i> </font color> </span>
          <a ui-scroll-to="content"><i class="fa fa-long-arrow-up p-x-sm"></i></a>
        </div>
        <div class="nav">

        </div>
      </div>
    </div>

    <!-- Fotter end -->

<!-- build:js scripts/app.html.js -->
<!-- jQuery -->
  <script src="../libs/jquery/jquery/dist/jquery.js"></script>
<!-- Bootstrap -->
  <script src="../libs/jquery/tether/dist/js/tether.min.js"></script>
  <script src="../libs/jquery/bootstrap/dist/js/bootstrap.js"></script>
<!-- core -->
  <script src="../libs/jquery/underscore/underscore-min.js"></script>
  <script src="../libs/jquery/jQuery-Storage-API/jquery.storageapi.min.js"></script>
  <script src="../libs/jquery/PACE/pace.min.js"></script>

  <script src="scripts/config.lazyload.js"></script>

  <script src="scripts/palette.js"></script>
  <script src="scripts/ui-load.js"></script>
  <script src="scripts/ui-jp.js"></script>
  <script src="scripts/ui-include.js"></script>
  <script src="scripts/ui-device.js"></script>
  <script src="scripts/ui-form.js"></script>
  <script src="scripts/ui-nav.js"></script>
  <script src="scripts/ui-screenfull.js"></script>
  <script src="scripts/ui-scroll-to.js"></script>
  <script src="scripts/ui-toggle-class.js"></script>

  <script src="scripts/app.js"></script>

  <script src="../libs/jquery/jquery-pjax/jquery.pjax.js"></script>
  <script src="scripts/ajax.js"></script>
  <script src="scripts/central.js"></script>
<!-- endbuild -->
</body>
</html>
