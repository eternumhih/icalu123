<?php
error_reporting(0);
session_start();
if(!isset($_SESSION['usuario']) or !isset($_SESSION['senha'])){
  echo "<script>location.href='/'</script>";
  die();
}
$array_usuarios = file("../../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){


    $_SESSION['senha'] = $explode[1];
    $_SESSION['rank'] = $explode[2];
    $_SESSION['creditos'] = $explode[3];
    $_SESSION['foto'] = $explode[4];
  }
}


$array_ccs_aprovadas = file_get_contents("../includes/ccs_aprovadas.txt");
$total_ccs_aprovadas = strlen($array_ccs_aprovadas);

$array_logins_aprovados = file_get_contents("../includes/logins_aprovados.txt");
$total_logins_aprovados = strlen($array_logins_aprovados);

$files_checkers = scandir(getcwd()."/");
$total_checkers = 0;

for($i=0;$i<count($files_checkers);$i++){
if(strpos($files_checkers[$i] , ".php") !== false){
  $total_checkers++;
}
}
$total_checkers--;

$usuario = $_SESSION['usuario'];
$creditos = $_SESSION['creditos'];
$rank = $_SESSION['rank'];
$foto = $_SESSION['foto'];

?>

<center>
   <div class="animated bounceInDown" id="formulario">
        <table class="display" id="example">
            <center>
      <br>
       <font size="7">Allbins v2 </font><br>
      <font size="2">  </font>
      <br><br>
              <textarea id="text" placeholder="Formato: email|senha" class="form-control" style="max-width: 800px; min-width: 800px; min-height: 200px; max-height: 200px; text-align: center;" placeholder=""></textarea>
                <br>
                <center>
                    Status: <span class="label info" id="status">Aguardando Iniciar...</span>
            <div>
            Aprovadas: <span id="aprovada_conta" class="label rounded green">0</span> | Reprovadas: <span id="reprovada_conta" class="label rounded red">0</span> | Testadas: <span id="testado" class="label rounded warn">0</span> | Total: <span id="tudo_conta" class="label rounded blue">0</span>
            </div>
            
            
                </center>
        
    </div>
   
     <button id="testar" onclick="iniciar('allbins2');" class="md-btn md-raised m-b- blue">INICIAR CHECKER</button>
    <br>
</center>


        <div class="col-sm-6">
      <p class="m-a-0 m-b"></p>
      <div ui-jp="nestable" class="dd">
        <ol class="dd-list dd-list-handle">
          <li class="dd-item">
              <div class="dd-content box"><div class="dd-handle"><font color="1ABE88"><strong><i class="fa fa-check text-muted"></i></div>Aprovadas</div>
              <ol class="dd-list" id="aprovadas"></font></strong>
                      
                  
              </ol>
          </li>
        </ol>
      </div>
    </div>
  </div>
</div>
    
    
    <div class="col-sm-6">
      <p class="m-a-0 m-b"></p>
      <div ui-jp="nestable" class="dd">
        <ol class="dd-list dd-list-handle">

          <li class="dd-item">
              <font color="#DA514A"><strong><div class="dd-content box"><div class="dd-handle"><i class="fa fa-close text-muted"></i></div>Reprovadas</div>
              <ol class="dd-list" id="reprovadas"></font></strong>

                  
              </ol>
          </li>
        </ol>
      </div>
    </div>
  </div>
</div>

  <script src="scripts/config.lazyload.js"></script>

  <script src="scripts/ui-load.js"></script>
  <script src="scripts/ui-jp.js"></script>

  <script>
     $('[ui-jp]').uiJp();
  </script>
