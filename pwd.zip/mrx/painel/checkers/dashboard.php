<?php
error_reporting(0);
set_time_limit(0);
session_start();

if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
echo '<script language= "JavaScript">location.href="/"</script><br>';
  die();
}

$array_usuarios = file("../../usuarios.txt");
$total_usuarios_registrados = count($array_usuarios);

for($i=0;$i<count($array_usuarios);$i++){
  $explode = explode("|" , $array_usuarios[$i]);
  if($_SESSION['usuario'] == $explode[0]){


    $_SESSION['senha'] = $explode[1];
    $_SESSION['rank'] = $explode[2];
    $_SESSION['foto'] = $explode[3];
  }
}


$array_ccs_aprovadas = file_get_contents("../includes/ccs_aprovadas.txt");
$total_ccs_aprovadas = strlen($array_ccs_aprovadas);

$array_logins_aprovados = file_get_contents("../includes/logins_aprovados.txt");
$total_logins_aprovados = strlen($array_logins_aprovados);

$files_checkers = scandir(getcwd()."/");
$total_checkers = 0;

for($i=0;$i<count($files_checkers);$i++){
if(strpos($files_checkers[$i] , ".php") !== false){
  $total_checkers++;
}
}
$total_checkers--;

$usuario = $_SESSION['usuario'];
$creditos = file_get_contents ("../../users/".$_SESSION['usuario'].".txt");

$rank = $_SESSION['rank'];
$foto = $_SESSION['foto'];

?>
<div class="animated bounceInDown" id="formulario">
        <table class="display" id="example">
<div class="padding">
  <div class="margin">
    <h5 color="goldenrod" >Olá  <?=$usuario ?>, Você esta logado na  CENTRAL STRIKER 1.0  <i class="faa-pulse animated"></i></h5>
    <font  color="goldenrod"><p>Um soldado da tiros, um carder tem sua conta. e seu cartão em segundos..</p></font>


  </div>

  <div class="row">
     <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box p-a">
          <div class="pull-left m-r">
            <span class="w-40 warn text-center rounded">
              <i class="material-icons">person_add</i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"> <?php echo $total_usuarios_registrados; ?> Total <span class="text-sm"></span></a></h4>
            <small class="text-muted">Usuarios Registrados</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
         <div class="box p-a">
          <div class="pull-right m-l">
            <span class="w-40 dker text-center rounded">
              <i class="fa fa-dollar"></i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><?php echo $total_logins_aprovados ?><span class="text-sm"></span></a></h4>
            <small class="text-muted">Logins lives </small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box p-a">
          <div class="pull-right m-l">
            <span class="w-40 accent text-center rounded">
              <i class="fa fa-spin fa fa-gear"></i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><?php echo $total_checkers ?> <span class="text-sm"> Checkers</span></a></h4>
            <small class="text-muted">Ferramentas/Checkers</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box p-a">
          <div class="pull-left m-r">
            <span class="w-40 dker text-center rounded">
              <i class="fa fa-credit-card"></i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><?php echo $total_ccs_aprovadas ?> <span class="text-sm"></span></a></h4>
            <small class="text-muted">CC LIVES</small>
          </div>
        </div>
      </div>
  </div>


            <?php

		?>
		<?php


$status = $_SESSION['rank'];
    switch ($status) {
		 case 'Usuario Free':
         $status = 'Usuario Free';
         $cor = 'gray';
         break;
         case 'Usuario Vip':
         $status = 'Usuario Vip';
         $cor = '#DDBA3E;';
         break;
         case 'Administrador':
         $status = 'Administrador';
         $cor = 'red';
         break;
    }

	//Creditos

if($creditos > "0"){
$defcreditos = "<b style='color:green;'>$creditos</b>";
}else{
$defcreditos = "<b style='color:red;'>$creditos</b>";
}
	?>

<div class="col-xs-6 col-sm-12 col-md-6">
          <div class="box">
            <div class="item">
              <div class="item-bg primary h1">
              <CENTER>  <p class='animated bounceIn alert '>Seu perfil!</p></CENTER>

              </div>
              <div class="p-a p-y-lg pos-rlt">
                <img src="<?php echo $_SESSION['foto']; ?>" class="img-circle w-56" style="margin-bottom: -7rem">
              </div>
          </div>
            <div class="p-a">
          <br>
			       <li class="list-group-item">
      <b>User:</b> <a class="pull-right"> <?php echo $usuario; ?></font>		</a>  <li class="list-group-item">
                                                <b>Créditos:</b> <a class="pull-right"> <?php echo $defcreditos; ?></font>		</a>
                                            </li>
                                            <li class="list-group-item">
                                                <b>Level:</b> <a class="pull-right"><?php echo "<font color='".$cor."'><strong>".$status."</font></strong>"?></a>
                                            </li>
                                            <li class="list-group-item">
                                                <b>Ip:</b> <a class="pull-right"><?php echo"$ip"?></a>
</div>
  <?php
if($_SESSION['rank'] == "Administrador"){
    ?>

  <a class="dropdown-item" href="javascript:refresh('admin.php')">
    <span>Administração</span>
  </a>

    <?php }?>
              </div>
            </div>
                    </div>
<div class="col-xs-6 col-sm-6"><div class="box p-a"><center><img  <img src="../assets/images/logo.png" height="35" width="36"></img> <center><small>{BOT INFORMATIVO}</small></center><br> <span class="label pink m-l-xs" id="rank2"><h6><marquee> tabela de creditos 100$ - 130c | 200$ - 250c | 300$ 350c | 400$ 450c </marquee> </h6></span></div></div>
<center><script src="https://apis.google.com/js/platform.js"></script>
<h6> Inscreva-se Sz </h6>
<div class="g-ytsubscribe" data-channelid="UC7eS3qObv9aTCr78qqG4uRg" data-layout="full" data-theme="dark" data-count="default"></div><center>          </div>

        </div>

          </div>





              </div>
            </div>
