<?php

session_start();
error_reporting(0);
if(!isset($_SESSION['usuario']) and !isset($_SESSION['senha'])){
  die();
}

?>
<!-- dropdown -->
<div class="dropdown-menu dropdown-menu-overlay pull-right w-xl animated fadeInUp no-bg no-border no-shadow">
    <div class="scrollable" style="max-height: 220px">
      <ul class="list-group list-group-gap m-0">
        <li class="list-group-item dark-white text-color box-shadow-z0 b">
          <span class="pull-left m-r">
            <img src="img/striker.png	" alt="..." class="w-40 img-circle">
          </span>
          <span class="clear block">
            <a href class="text-primary">>>ADM<<</a><br> Compre VIP e aproveite nossa Central.<br>
            <small class="text-muted"><?php
$dataAtual = date("d/m/Y");
echo $dataAtual;
?></small>
          </span>

        </li>
      </ul>
    </div>
</div>



		