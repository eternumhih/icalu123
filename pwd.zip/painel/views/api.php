<?php

error_reporting(0);
set_time_limit(0);
session_start();


if(!isset($_SESSION['usuario']) or !isset($_SESSION['senha'])){
  echo "<script>location.href='/'</script>";
  die();
}

extract($_SESSION);

$ckfile = getcwd(). "/cookie.txt";
if(file_exists($ckfile)){
	unlink($ckfile);
}

function contar_login(){
$fp = fopen("includes/logins_aprovados.txt" , "a+");
fwrite($fp, "0");
fclose($fp);


}
function pagseguro($lista){
	

}

function dotz($lista){

}


if(isset($_GET['lista']) and isset($_GET['testar'])){

if($creditos <= 110){
die("creditos");
}
$lista = $_GET['lista'];
$lista = trim($lista);
$lista = str_replace(" ", "", $lista);
$servidor = $_GET['testar'];

switch ($servidor) {
	case 'pagseguro':
	pagseguro($lista);

		break;

  case 'dotz':
  dotz($lista);

    break;
	default:
	

		break;

}
}

?>