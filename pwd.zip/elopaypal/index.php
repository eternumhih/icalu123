﻿<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>CHECKER DE GG ELO SE SAIR MUITA LIVE SUA MATRIX N E ACEITA</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" href="imagem/icon0.png">
    <style>
       body{
       background: url('imagem/hiu.jpg') no-repeat center center fixed;
       background-size: cover;
       -webkit-background-size: cover; /* SAFARI / CHROME */
       -moz-background-size: cover; /* FIREFOX */
       -ms-background-size: cover; /* IE */
       -o-background-size: cover; /* OPERA */
       }
        h1{
            font-family: 'Press Start 2P', cursive;
            color: white;
        }
        textarea{
            margin-top: 0px; margin-bottom: 0px; height: 149px;
            background: transparent;
            color: white;
            text-align: center;
            font-size: 30px;
            width: 60%;
            resize: none;
            outline: none;
        }
        #list{
            resize: none;
        }
        .nav.nav-tabs + .tab-content {
            background: #ffffff;
            margin-bottom: 30px;
            padding: 30px;
        }

        .tabs-vertical-env .tab-content {
            background: #ffffff;
            display: table-cell;
            margin-bottom: 30px;
            padding: 30px;
            vertical-align: top; 
        }

        .search-result-box .tab-content {
            padding: 30px 30px 10px 30px;
            box-shadow: none; }
     

    </style>
    <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.1.3/minty/bootstrap.min.css" rel="stylesheet" integrity="sha384-Qt9Hug5NfnQDGMoaQYXN1+PiQvda7poO7/5k4qAmMN6evu0oDFMJTyjqaoTGHdqf" crossorigin="anonymous">
</head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script>
        var audio = new Audio('blop.mp3');
            $(document).ready(function () {
                $('#status').html('<span id="bad" class="badge badge-dark">Não iniciado !</span>');
                $('#start').attr('disabled', null);
                $('#clear').attr('disabled','disabled');
                $('#stop').attr('disabled','disabled');
                $('#start').click(function () {
                    audio.play();
                    var line = $('#list').val().split('\n');
                    var total = line.length;
                    var ap = 0;
                    var rp = 0;
                    var sd = 0;
                    $('#total').html(total);
                    line.forEach(function (value) {
                        var ajaxCall = $.ajax({
                            url: 'api.php',
                            type: 'GET',
                            data: 'lista=' + value,
                            beforeSend: function () {
                                $('#status').html('<span class="badge badge-dark">Testando !</span>');
                                $('#stop').attr('disabled',null);
                                $('#stop').attr('disabled',null);
                                $('#start').attr('disabled','disabled');
                            },

            success: function(data){
                if(data.indexOf("APROVADA") >= 0){
                    $('#status').html('<span class="badge badge-dark">Aprovada...</span>');
                    $("#aprovadas").val(data + "\n" + $("#aprovadas").val());
                    ap = ap + 1;
                    document.getElementById("lives").innerHTML += data;
                    audio.play();
                    removelinha();

                }else{
                    $("#reprovadas").val(data + "\n" + $("#reprovadas").val());
                    $('#status').html('<span id="bad" class="badge badge-danger">reprovada...</span>');
                    rp = rp + 1;
                    document.getElementById("dies").innerHTML += data;
                    removelinha();
                }

                    var fila = parseInt(ap) + parseInt(rp);
                    $('#live').html(ap);
                    $('#die').html(rp);
                    $('#testadas').html(fila);
                    if (fila == total) {
                        $('#start').attr('disabled', null);
                        $('#stop').attr('disabled', 'disabled');
                        $('#clear').attr('disabled',null);
                        $('#status').html('<span class="badge badge-dark">Teste Finalizado !</span>');
                        audio.play();
                    }
                }

            });

             $('#stop').click(function(){
            ajaxCall.abort();
            $('#start').attr('disabled',null);
            $('#stop').attr('disabled','disabled');
            $('#clear').attr('disabled',null);
          });


        });

        $('#stop').click(function(){
          $('#status').html('<span class="badge badge-danger">Parado !</span>');
          
        });


        
        $('#clear').click(function(){
        $('#status').html('<span class="badge badge-secondary">Lista Limpa!</span>');
                $('#list').val('');
            });
            });
        });
        function removelinha() {
            var lines = $("#list").val().split('\n');
                lines.splice(0, 1);
                $("#list").val(lines.join("\n"));
            }

       
        </script>
<body>
    <center><br>
        <div class="checker">
            <div class="info-checker">
                <h1 style="font-family: 'Righteous', cursive; color: white;"><i class=""></i> <span class="badge badge-custom" id="aguardando666">CHK ELO 6504XX 6363XX 509069XX</span> <i class=""></i></i></h1>

                <h6 style="color: white;"><i class="fas fa-code"></i>@ren<i class="fas fa-code"></i>
                </h6>
            </div>
            <div class="form-group">
                <textarea name="lista" style="color: white;" placeholder="0000000000000000|00|0000|000" id="list" rows="7" required="" cols="2"></textarea>
            </div>

            <div class="info-lista">
                <font color="white"><b>Status: </b><span id="status"></span><p></p>Aprovadas : <span id="live" class="badge badge-dark">0</span>  Reprovadas : <span id="die" class="badge badge-dark">0</span> Testadas: <span id="testadas" class="badge badge-dark">0</span>  Total : <span id="total" class="badge badge-dark">0</span> </font><br><br>
            </div>

            <div class="button-list">
                <button style="width: 100px;border-color: black;" type="button" type="submit" id="start" class="btn btn-dark">INICIAR</button>
                <button style="width: 100px; border-color: black;" type="button" type="submit" id="stop" class="btn btn-dark">PARAR</button>
            </div><br>
            
            <div class="" style="max-width: 55rem;">
                <div style="background-color: #000000; color: white;" class="card-header">Aprovadas</div>
                <div id="lives" class="card-body">
                </div>
            </div>

            <div class="" style="max-width: 55rem;">
                <div style="background-color: #000000; color: white;" class="card-header">Reprovadas</div>
                <div id="dies" class="card-body">
                   <tbody id="dies"></tbody>
                </div>
            </div>
    </center>
</body>
</html>